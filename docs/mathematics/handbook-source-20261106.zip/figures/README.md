# R-SCHA 数学图件：完整四阶重建版

本目录的全部正文图已重新绘制。原始图、第一轮 `_v2` 试图和旧代码集中保存在
`_archive/before_complete_refresh_20261024/`，不再参与正文引用。

## 先看什么

- `overview.png`：16 张正文图的总览。
- `RSCHA_Figure_Atlas.pdf`：包含全部正文图、二维/三维补充图、读图说明和核验结果的逐页图册。
- `Legendre_Complete.pdf`：Legendre 完整组合和对应曲线。
- `Mehler_Complete.pdf`：Mehler 函数、导数及对应曲线。
- `Constant_Complete.pdf`：常数族完整组合和对应曲线。
- `Geometry_and_Indices.pdf`：几何、边界根和坐标旋转。
- `Angular_and_Radial_Curves.pdf`：四类函数及一、二阶导数曲线。

## 完整组合的含义

| 家族 | 显示范围 | 余弦模式 | 正弦模式 | 有效实模式总数 |
|---|---|---:|---:|---:|
| Legendre | `0 <= m <= k <= 4` | 15 | 10 | 25 |
| Mehler | `1 <= p <= 4`，`0 <= m <= 4`，独立取值 | 20 | 16 | 36 |
| 零径向特征值的常数族 | `0 <= m <= 4` | 5 | 4 | 9 |

“四阶”指索引覆盖到 4；仍展示函数及一、二阶导数，与手册的推导对应。
Mehler 不施加 `m <= p`。`p=0` 不属于这里的三维 Mehler 径向谱；
零径向特征值由独立的常数族表示。
所有 `m=0` 的正弦项恒为零，因此不列作基函数。常数族 `m=0` 的导数图保留，并明确标为零。

模式图统一采用九列：`sin(4λ)`、`sin(3λ)`、`sin(2λ)`、`sin(λ)`、`1`、
`cos(λ)`、`cos(2λ)`、`cos(3λ)`、`cos(4λ)`。
Legendre 的行索引为 `k=0..4`；Mehler 的行索引为 `p=1..4`。
Legendre 三角域之外的淡色短横线表示该索引不在所展示的集合中。

## 统一的参考参数与数学约定

- 球冠半张角：`theta0 = 30 deg`。
- 参考球壳：`ra=1`，`rb=2`，所以 `s=ln(2)`，`tau_p=p*pi/ln(2)`。
- 这是明确给定的教学参考几何，不代表实际地磁应用的壳体参数。相比先前试图中的
  `theta0=5 deg, s=1`，这一组参数更适合展示完整低阶函数的空间形态。
- Legendre 使用第 9 节的地球物理 Schmidt 半归一化：Ferrers 函数中的
  Condon--Shortley 相位与 Schmidt 因子中的相位相消。
- Mehler、常数角函数满足 `integral A(theta)^2 sin(theta) dtheta = 1`。
- 径向函数满足 `integral Rp(r)^2 dr = ra`。
- 所有角导数按弧度求导；横坐标可用度表示。

曲线按固定 `m` 分栏，所有曲线坐标均为线性坐标，便于直接比较函数与导数。
原先由 `symlog` 转换阈值造成的显示弯折不再存在。

## 三维与二维的对应关系

正文的基函数图 `fig5(a)`、`fig7(a)`、`fig9(a)` 采用三维球冠径向起伏图：

`R_display = 1 + 0.16 * f / max(abs(f))`。

蓝色为负、米白为零、赭红为正；虚线圆是未变形参考球冠的边缘。
径向起伏是函数值的显示编码。各小图独立按自己的最大绝对值缩放；
实际函数幅度及导数幅度保存在 `data/display_amplitudes.csv`。

正文函数及一、二阶导数模式图统一采用三维球冠显示。
`supplement/` 提供对应的二维版本。曲线图四边框均显示（box on）。
角导数图略去坐标极点，避免把极点处依赖经向的坐标导数强行视为单值标量。

## 文件对应关系

| 文件 | 重建后的内容 |
|---|---|
| `fig1.png` | 参考 Geometry_Algorithm_Figure 的倾斜球冠、半透明边界与白色虚网格；左为闭球壳，右为二维球冠曲面 |
| `fig2.png` | Legendre 连续度边界曲线与完整 15 个非整数根表 |
| `fig4.png` | 全部 15 个 `(k,m)` 组合的 Legendre 函数及导数 |
| `fig5(a).png` | 25 个 Legendre 实模式，三维 |
| `fig5(b).png`, `fig5(c).png` | 全部模式的一、二阶角导数，三维 |
| `fig6.png` | 全部 20 个 `(p,m)` 组合的 Mehler 函数及导数 |
| `fig7(a).png` | 36 个 Mehler 实模式，三维 |
| `fig7(b).png`, `fig7(c).png` | 全部模式的一、二阶角导数，三维 |
| `fig8.png` | `m=0..4` 的常数角函数及导数 |
| `fig9(a).png` | 常数族全部 9 个实模式，三维 |
| `fig9(b).png`, `fig9(c).png` | 全部模式的一、二阶角导数，三维 |
| `fig10.png` | `p=0..4` 的径向 Neumann 函数及导数 |
| `fig11.png` | 还原原始四格构图：全局坐标、经度旋转、余纬旋转、最终球冠坐标；黑/蓝/红三阶段配色 |

原文件名保持与 LaTeX 引用相容；相关章节的图注已同步更新。
章节原稿备份位于旧图归档中的 `caption_sources/`。
本次图件已接入手册并完成重新编译。最终手册为根目录的 `main.pdf` 和同名带标题的 PDF；
本次移除了 Mehler 指标分布的专项说明及对应示意图。

## 代码与再生成

- `code/basis.py`：正则解析函数、归一化、非整数根与解析导数。
- `code/geometry_drawings.py`：参考已认可的球冠示意图，并还原原始四格坐标旋转图。
- `code/rebuild_all.py`：全部图件、CSV 和 PDF 图册。
- `code/validate.py`：独立的 60 位高精度核验。
- `requirements.txt`：Python 依赖。
- `rebuild.ps1`：当前电脑可直接使用的入口；也支持 `-PythonExe` 指定解释器。

在本目录执行：

```powershell
.\rebuild.ps1
```

其他环境安装依赖后执行：

```text
python -m pip install -r requirements.txt
python code/validate.py
python code/rebuild_all.py
```

需要调整教学参数时，在 `code/basis.py` 中修改 `APERTURE_DEG`、`RA`、`RB`，
并同步修改 `code/validate.py` 的高精度参考参数及 `code/rebuild_all.py` 的说明文字。
此脚本针对当前明确给定的低阶展示范围；扩展至高阶应使用项目的稳定计算接口并重新核验。

## 独立核验

`data/validation.json` 记录逐项结果：480 次函数值/导数核对；60 位 Mehler
参考采用另一种超几何表示；角范数以独立的 512 点 Gauss 求积核对。
同时检查角微分方程、Legendre 正交性、径向正交性以及两端 Neumann 条件。
该核验针对本图册的数据，范围不包括已编译 C++ atlas 的整体性能与精度。

`vector/` 保存每张图的 PDF，线图另有 SVG；`reports/` 保存读图说明与核验页。
根目录六本 PDF 是由这些单图 PDF 组装的浏览图册。正文图和补充图均由新代码生成。

## 几何与旋转图的参考修订

`fig1` 的构图、半透明球冠和加粗的白色虚网格参考
`E:\OneDrive\学习\R-SCHA Shell C++\Geometry_Algorithm_Figure` 中的已认可版本。
示意图半径用于清晰区分边界，数值曲线的参考球壳参数仍以 `data/parameters.json` 为准。
符号采用数学手册的 `r_a`、`r_b`、`Gamma` 和经度 `lambda`。

`fig11` 以原始归档图为构图依据恢复四格，并以正交投影保持轴的空间关系。
全局坐标使用墨黑、中间坐标使用蓝色、最终坐标使用红色。
固定的球冠中心在四格中保持同一空间位置；其方向由旋转后的正 `Z_c` 轴表示。


