"""Complete, reproducible replacement of all handbook figures.

Run: python code/rebuild_all.py
Outputs: canonical PNGs, vector PDFs/SVGs, alternative 2D/3D atlases,
numerical CSVs, a contact sheet, and a multi-page review atlas.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Rectangle, FancyBboxPatch
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image, ImageOps, ImageDraw, ImageFont
from basis import (APERTURE_DEG, T0, RA, RB, S, MAX_INDEX, basis, modes,
                   degree, roots, boundary_residual, radial)

ROOT = Path(__file__).resolve().parents[1]
INK, MUTED = '#263B4B', '#6D7D89'
TEAL, BLUE, GOLD = '#32858B', '#537FA6', '#B78B48'
LINE_COLORS = ['#273D55', '#337EA5', '#36A19C', '#BD8045', '#946A9C']
CMAP = LinearSegmentedColormap.from_list('rscha_signed', ['#29577A', '#73AFC0', '#F4F4EE', '#E6A97D', '#A94446'], N=256)
FAMILY_NAMES = {'legendre': 'Legendre cap harmonics', 'mehler': 'Mehler cap harmonics',
                'constant': 'Zero-eigenvalue cap harmonics'}
FIELD_NAMES = ['Basis functions', 'First colatitudinal derivatives', 'Second colatitudinal derivatives']
SPECS = []
STATS = []
plt.rcParams.update({'font.family':'STIXGeneral', 'mathtext.fontset':'stix',
    'font.size':11, 'text.color':INK, 'axes.labelcolor':INK, 'axes.edgecolor':INK,
    'xtick.color':MUTED, 'ytick.color':MUTED, 'axes.spines.top':True,
    'axes.spines.right':True, 'axes.linewidth':.8, 'axes.titlepad':8,
    'legend.frameon':False, 'pdf.fonttype':42, 'svg.fonttype':'none',
    'savefig.facecolor':'white', 'figure.facecolor':'white', 'axes.unicode_minus':True})


def save(fig, name, title, category, raster=False):
    target = ROOT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(target.with_suffix('.png'), dpi=320, facecolor='white')
    vector = ROOT / 'vector' / Path(name).parent / (Path(name).stem + '.pdf')
    vector.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(vector, dpi=220, facecolor='white')
    if not raster:
        fig.savefig(vector.with_suffix('.svg'), facecolor='white')
    SPECS.append({'file':str(target.with_suffix('.png').relative_to(ROOT)),
                  'pdf':str(vector.relative_to(ROOT)), 'title':title, 'category':category})
    plt.close(fig)
    print('saved', name, flush=True)


def header(fig, title, subtitle):
    fig.text(.055, .961, title, fontsize=20, weight='bold', va='top')
    fig.text(.055, .910, subtitle, fontsize=11, color=MUTED, va='top')


def clean_axis(ax):
    for spine in ax.spines.values():
        spine.set_visible(True)
    ax.grid(axis='both', color='#DAE2E6', lw=.55, alpha=.8)
    ax.set_axisbelow(True)
    ax.tick_params(labelsize=8.5, length=3)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(-3,4), useMathText=True)
    ax.yaxis.get_offset_text().set_fontsize(8)
    ax.locator_params(axis='y', nbins=4)


def function_curves(family, filename):
    fig = plt.figure(figsize=(12, 8))
    norm_label = 'Geophysical Schmidt semi-normalisation (handbook convention)' if family=='legendre' else 'Cap-unit normalisation'
    header(fig, FAMILY_NAMES[family].replace('cap harmonics','angular functions'),
           rf'{norm_label}  |  $\theta_0={APERTURE_DEG:g}^\circ$' + (rf'  |  $r_b/r_a={RB/RA:g}$' if family=='mehler' else ''))
    t = np.linspace(0, T0, 1401)
    for q in range(3):
        for m in range(5):
            ax = fig.add_axes([.07+m*.185, .145+(2-q)*.232, .155, .177])
            indices = range(m,5) if family=='legendre' else range(1,5)
            for i in indices:
                values = basis(family, i, m, t)[q]
                ax.plot(np.degrees(t), values, color=LINE_COLORS[i], lw=1.65)
            clean_axis(ax)
            ax.set_xlim(0, APERTURE_DEG)
            if q==0: ax.set_title(rf'$m={m}$', fontsize=13)
            if q==2: ax.set_xlabel(r'$\theta$ (deg)', fontsize=10)
            else: ax.tick_params(labelbottom=False)
            if m==0:
                symbol = r'\widetilde P' if family=='legendre' else r'\widetilde K'
                ax.set_ylabel([rf'${symbol}$', rf'$\partial_\theta {symbol}$', rf'$\partial_\theta^2 {symbol}$'][q], fontsize=14)
    key = 'k' if family=='legendre' else 'p'
    start=0 if family=='legendre' else 1
    handles=[plt.Line2D([],[],color=LINE_COLORS[i],lw=2,label=rf'${key}={i}$') for i in range(start,5)]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5,.038), ncol=5, fontsize=11)
    fig.text(.5,.020,'All angular derivatives are with respect to radians. All axes are linear.', ha='center', fontsize=9,color=MUTED)
    save(fig, filename, FAMILY_NAMES[family]+' - complete angular curves','curves')


def constant_curves():
    fig=plt.figure(figsize=(12,4.4))
    header(fig, 'Zero-eigenvalue angular functions', rf'Cap-unit normalisation  |  $\theta_0={APERTURE_DEG:g}^\circ$  |  $m=0,\ldots,4$')
    t=np.linspace(0,T0,1401)
    for q in range(3):
        ax=fig.add_axes([.075+q*.308,.235,.265,.52])
        for m in range(5):
            ax.plot(np.degrees(t),basis('constant',0,m,t)[q],color=LINE_COLORS[m],lw=1.8,label=rf'$m={m}$')
        clean_axis(ax)
        ax.set_xlabel(r'$\theta$ (deg)')
        ax.set_xlim(0,APERTURE_DEG)
        ax.set_ylabel([r'$\widetilde P_0^m$',r'$\partial_\theta\widetilde P_0^m$',r'$\partial_\theta^2\widetilde P_0^m$'][q],fontsize=14)
        if q==1: ax.set_title('First derivative',fontsize=12)
        elif q==2: ax.set_title('Second derivative',fontsize=12)
        else: ax.set_title('Angular function',fontsize=12)
    fig.legend(*fig.axes[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.5,.055),ncol=5)
    fig.text(.5,.023,'The order-zero derivatives are exactly zero; angular derivatives use radians.',ha='center',fontsize=9,color=MUTED)
    save(fig,'fig8','Zero-eigenvalue functions and derivatives','curves')


def color_scale(fig,y=.033):
    cax=fig.add_axes([.38,y,.25,.012])
    cb=fig.colorbar(ScalarMappable(norm=Normalize(-1,1),cmap=CMAP),cax=cax,orientation='horizontal',ticks=[-1,0,1])
    cb.outline.set_visible(False)
    cb.ax.tick_params(length=0,labelsize=9,pad=2)
    fig.text(.505,y+.024,r'$f/\max|f|$ for each mode',ha='center',color=MUTED,fontsize=10)


def atlas(family,q,filename,view='3d'):
    rows = list(range(5)) if family=='legendre' else (list(range(1,5)) if family=='mehler' else [0])
    nrows=len(rows)
    width,cell=15.3,1.25
    height=nrows*cell+2.3
    fig=plt.figure(figsize=(width,height))
    fig.text(.055,.965,FAMILY_NAMES[family]+' | '+FIELD_NAMES[q],fontsize=20,weight='bold',va='top')
    normtext='Schmidt semi-normalised' if family=='legendre' else 'cap-unit normalised'
    modecount=25 if family=='legendre' else (36 if family=='mehler' else 9)
    if view=='3d':
        message='3D spherical caps; radial relief = 0.16 f/max|f|'
    else: message=r'Polar maps; radius = $\theta/\theta_0$'
    fig.text(.055,.965-.38/height,
             rf'{modecount} real modes  |  {normtext}  |  $\theta_0={APERTURE_DEG:g}^\circ$  |  '+message,
             fontsize=11,color=MUTED,va='top')
    cols=list(range(-4,5))
    left,right=.073,.985
    cw=(right-left)/9
    top=1-1.35/height
    cellh=cell/height
    for j,c in enumerate(cols):
        label=rf'$\sin({abs(c)}\lambda)$' if c<0 else (r'$1$' if c==0 else rf'$\cos({c}\lambda)$')
        fig.text(left+(j+.5)*cw,top+.11/height,label,ha='center',va='bottom',fontsize=12)
    for row,i in enumerate(rows):
        if family!='constant':
            fig.text(.04,top-(row+.5)*cellh,rf'${"k" if family=="legendre" else "p"}={i}$',ha='center',va='center',fontsize=14,rotation=90)
        for j,c in enumerate(cols):
            m=abs(c)
            rect=[left+j*cw,top-(row+1)*cellh,cw,.99*cellh]
            if family=='legendre' and m>i:
                ax=fig.add_axes(rect);ax.axis('off')
                ax.text(.5,.5,'—',ha='center',va='center',color='#D7DFE3',fontsize=18)
                continue
            if view=='3d':
                ax=fig.add_axes(rect,projection='3d')
                tt=np.linspace(0 if q==0 else .012*T0,T0,52)
                pp=np.linspace(-np.pi,np.pi,97)
                T,P=np.meshgrid(tt,pp,indexing='ij')
                f=basis(family,i,m,tt)[q][:,None]* (np.sin(m*P) if c<0 else np.cos(m*P))
                normmax=float(np.max(np.abs(basis(family,i,m,np.linspace(0,T0,2001))[q])))
                scaled=f/normmax if normmax>1e-13 else np.zeros_like(f)
                radius=1+.16*scaled
                x=radius*np.sin(T)*np.cos(P); y=radius*np.sin(T)*np.sin(P); z=radius*np.cos(T)
                surf=ax.plot_surface(x,y,z,facecolors=CMAP((scaled+1)/2),rstride=1,cstride=1,linewidth=0,antialiased=True,shade=False)
                surf.set_rasterized(True)
                phi=np.linspace(0,2*np.pi,240)
                ax.plot(np.sin(T0)*np.cos(phi),np.sin(T0)*np.sin(phi),np.cos(T0)*np.ones_like(phi),color='#9DACB6',lw=.55,ls=(0,(2,2)),alpha=.7)
                ax.plot(x[-1],y[-1],z[-1],color=INK,lw=.5,alpha=.8)
                ax.set(xlim=(-.64,.64),ylim=(-.64,.64),zlim=(.67,1.21))
                ax.set_box_aspect((1,1,.54/1.28),zoom=1.55)
                ax.view_init(elev=43,azim=-57)
                ax.set_proj_type('ortho');ax.set_axis_off()
                if normmax<1e-13: ax.text(0,0,1.04,'0',ha='center',color=MUTED,fontsize=12)
            else:
                ax=fig.add_axes(rect)
                xx=np.linspace(-1.03,1.03,251)
                X,Y=np.meshgrid(xx,xx)
                r=np.hypot(X,Y); phi=np.arctan2(Y,X)
                t=np.clip(r,0,1)*T0
                fine_theta=np.linspace(0,T0,3601)
                fine_values=basis(family,i,m,fine_theta)[q]
                f=np.interp(t.ravel(),fine_theta,fine_values).reshape(t.shape)*(np.sin(m*phi) if c<0 else np.cos(m*phi))
                normmax=float(np.max(np.abs(fine_values)))
                scaled=f/normmax if normmax>1e-13 else np.zeros_like(f)
                scaled=np.ma.masked_where((r>1)|((r<.012)&(q>0)),scaled)
                ax.imshow(scaled,origin='lower',extent=[-1.03,1.03,-1.03,1.03],cmap=CMAP,vmin=-1,vmax=1,interpolation='bilinear')
                ax.add_patch(plt.Circle((0,0),1,fill=False,color=INK,lw=.55))
                ax.set_aspect('equal');ax.axis('off')
                if normmax<1e-13: ax.text(0,0,'0',ha='center',va='center',color=MUTED,fontsize=12)
            if not filename.startswith('supplement'):
                STATS.append({'family':family,'index':i,'m':m,'derivative_order':q,'parity':'sine' if c<0 else 'cosine','max_abs_value':normmax})
    color_scale(fig,y=.4/height)
    note='Sine order zero is identically zero and is omitted.'
    if family=='mehler': note+=rf' $\tau_p=p\pi/\ln2$.'.rstrip('.')
    if family=='legendre':note+=r' Dirichlet roots: $0\leq m\leq k\leq4$.'
    if q>0:note+=' The coordinate pole is omitted in derivative maps.'
    fig.text(.055,.068/height,note,va='bottom',fontsize=9.5,color=MUTED)
    save(fig,filename,FAMILY_NAMES[family]+' - '+FIELD_NAMES[q]+' ('+view+')','atlas',True)


def root_figure():
    fig=plt.figure(figsize=(10.5,7.3))
    header(fig,'Dirichlet spectrum on a spherical cap',rf'Continuous degree and its admissible roots  |  $\theta_0={APERTURE_DEG:g}^\circ$')
    ax=fig.add_axes([.085,.49,.865,.33])
    vmax=max(roots(0))+.7
    for m in range(5):
        nu=np.linspace(m+.0001,vmax,2401)
        residual=boundary_residual(nu,m)
        scale=max(abs(residual))
        ax.plot(nu,residual/scale,color=LINE_COLORS[m],lw=1.5,label=rf'$m={m}$')
        ax.scatter(roots(m),np.zeros(len(roots(m))),color=LINE_COLORS[m],s=19,zorder=5)
    ax.axhline(0,color=MUTED,lw=.7)
    ax.set(xlim=(0,vmax),ylim=(-1.08,1.14),xlabel=r'Continuous degree $\nu$',ylabel='Scaled regular boundary value')
    clean_axis(ax); ax.legend(loc='upper right',ncol=5,fontsize=10)
    table=fig.add_axes([.085,.13,.865,.22]);table.axis('off')
    table.text(0,1.12,r'Admissible non-integer degrees $\nu_{km}$',fontsize=13,weight='bold')
    vals=[]
    for k in range(5):vals.append([rf'$k={k}$']+[f'{degree(k,m):.6f}' if m<=k else '—' for m in range(5)])
    tb=table.table(cellText=vals,colLabels=['']+[f'm={m}' for m in range(5)],cellLoc='center',bbox=[0,0,1,1])
    tb.auto_set_font_size(False);tb.set_fontsize(10)
    for (r,c),cell in tb.get_celld().items():
        cell.set_edgecolor('white');cell.set_facecolor('#E7EFF2' if r==0 else ('#F2F6F7' if r%2 else 'white'))
        cell.get_text().set_color(INK)
    fig.text(.085,.052,'Each boundary curve is divided by its maximum absolute value. Dots show the roots used in the complete atlas.',fontsize=9,color=MUTED)
    save(fig,'fig2','Legendre boundary roots and complete degree table','geometry')


def radial_curves():
    fig=plt.figure(figsize=(12,4.5))
    header(fig,'Neumann radial eigenfunctions',r'Complete indices $p=0,\ldots,4$  |  $r_b/r_a=2$  |  $\int_{r_a}^{r_b}R_p^2\,dr=r_a$')
    r=np.linspace(RA,RB,2001)
    for q in range(3):
        ax=fig.add_axes([.075+.308*q,.235,.263,.52])
        for p in range(5):ax.plot(r/RA,radial(p,r)[q]*RA**q,color=LINE_COLORS[p],lw=1.7,label=rf'$p={p}$')
        clean_axis(ax)
        ax.set(xlim=(1,RB/RA),xlabel=r'$r/r_a$')
        ax.set_ylabel([r'$R_p$',r'$r_a\,\partial_r R_p$',r'$r_a^2\,\partial_r^2 R_p$'][q],fontsize=14)
        ax.set_title(['Function','First radial derivative','Second radial derivative'][q],fontsize=12)
    fig.legend(*fig.axes[0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.5,.05),ncol=5)
    fig.text(.5,.025,r'$R_0$ is constant. Every first derivative vanishes at both spherical boundaries.',ha='center',fontsize=9,color=MUTED)
    save(fig,'fig10','Radial Neumann eigenfunctions through p=4','curves')


def geometry():
    from geometry_drawings import draw_geometry
    save(draw_geometry(),'fig1','Three-dimensional shell and two-dimensional cap domains','geometry')


def rotation():
    from geometry_drawings import draw_rotation
    save(draw_rotation(),'fig11','Four-stage passive rotation from global to cap coordinates','geometry')


def export_data():
    d=ROOT/'data';d.mkdir(exist_ok=True)
    with (d/'legendre_degrees.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['k','m','nu','theta0_deg'])
        for k,m in modes('legendre'):w.writerow([k,m,degree(k,m),APERTURE_DEG])
    for family in FAMILY_NAMES:
        with (d/(family+'_curves.csv')).open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(['index','m','theta_deg','value','dtheta_per_rad','d2theta_per_rad2'])
            t=np.linspace(0,T0,801)
            for i,m in modes(family):
                y,dy,ddy=basis(family,i,m,t)
                w.writerows(zip(np.full(len(t),i),np.full(len(t),m),np.degrees(t),y,dy,ddy))
    with (d/'display_amplitudes.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(STATS[0]));w.writeheader();w.writerows(STATS)
    (d/'parameters.json').write_text(json.dumps({'theta0_deg':APERTURE_DEG,'ra':RA,'rb':RB,'shell_log':S,
        'max_index':4,'mehler_real_mode_count':36,'legendre_real_mode_count':25,'constant_real_mode_count':9,
        'angular_derivative_unit':'radians','3d_radial_relief':.16,'root_condition':'Dirichlet',
        'legendre_normalization':'geophysical Schmidt; Ferrers P phase cancelled by Schmidt factor as in section 9',
        'mehler_constant_normalization':'integral A(theta)^2 sin(theta) dtheta = 1'},indent=2),encoding='utf-8')


def guides():
    fig=plt.figure(figsize=(11.7,7.5))
    header(fig,'Reading the complete R-SCHA figure suite','One numerical definition per family; one visual grammar across all figures')
    cards=[(.055,'25','Legendre modes',r'$0\leq m\leq k\leq4$'),
           (.365,'36','Mehler modes',r'$1\leq p\leq4,\quad0\leq m\leq4$'),
           (.675,'9','Constant modes',r'$0\leq m\leq4$')]
    for x,count,title,rule in cards:
        fig.patches.append(FancyBboxPatch((x,.58),.27,.22,transform=fig.transFigure,
            boxstyle='round,pad=.012',facecolor='#EFF5F5',edgecolor='none'))
        fig.text(x+.025,.72,count,fontsize=34,color=TEAL,weight='bold')
        fig.text(x+.025,.66,title,fontsize=15,weight='bold')
        fig.text(x+.025,.605,rule,fontsize=14)
    details=[
        ('Reference geometry',r'$\theta_0=30^\circ$, $r_a=1$, $r_b=2$, $s=\ln 2$. These are explicit didactic parameters.'),
        ('Normalisation','Legendre: the geophysical Schmidt convention in section 9. Mehler and constant: cap-unit norm.'),
        ('Colour scale',r'Each panel shows $f/\max|f|$. Blue is negative, ivory is zero, and red is positive.'),
        ('Three-dimensional view',r'The reference unit cap is displaced radially by $0.16\,f/\max|f|$. Its dashed rim is undeformed.'),
        ('Derivatives','Angular derivatives use radians. All main mode panels are 3D and omit the coordinate pole for derivatives.'),
        ('Complete real basis',r'All nonzero cosine and sine modes are shown. The identically zero $m=0$ sine mode is omitted.'),
        ('Reproduction','Run code/validate.py and code/rebuild_all.py. Numerical curves and display amplitudes are exported as CSV.')]
    for n,(key,value) in enumerate(details):
        y=.50-n*.060
        fig.text(.055,y,key,fontsize=11.5,weight='bold')
        fig.text(.265,y,value,fontsize=10.5)
    save(fig,'reports/Figure_Guide','Figure definitions and display conventions','report')
    result=json.loads((ROOT/'data'/'validation.json').read_text(encoding='utf-8'))
    fig=plt.figure(figsize=(11.7,7.5))
    header(fig,'Independent numerical verification','60-digit references at plotting orders up to four; analytical derivatives and boundary conditions')
    fig.text(.055,.79,result['status'],fontsize=32,weight='bold',color=TEAL)
    fig.text(.25,.805,f"{result['angular_reference_checks']} value and derivative comparisons across 40 angular index/order pairs",fontsize=13)
    checks=[('Maximum scaled value or derivative error','max_scaled_value_or_derivative_error'),
            ('Cap-unit norm error: independent 512-point Gauss rule','max_cap_unit_norm_error_512_point_quadrature'),
            ('Scaled angular differential-equation residual','max_scaled_angular_ode_residual'),
            ('Legendre angular orthogonality error','max_normalized_legendre_gram_error'),
            ('Radial orthonormality error','max_radial_gram_error'),
            ('Radial Neumann boundary derivative','max_radial_neumann_boundary_derivative'),
            ('Schmidt Dirichlet boundary value','max_schmidt_dirichlet_boundary_value')]
    for n,(label,key) in enumerate(checks):
        y=.69-n*.067
        fig.text(.075,y,label,fontsize=12)
        fig.text(.82,y,f'{result[key]:.3e}',fontsize=13,color=TEAL,ha='right')
    fig.text(.075,.135,'Reference formulas use a different hypergeometric representation for Mehler values and high-precision differentiation.',fontsize=10.5,color=MUTED)
    fig.text(.075,.095,'Scope: verification of the illustration data. This is not a performance or accuracy benchmark of the compiled C++ atlas.',fontsize=10.5,color=MUTED)
    save(fig,'reports/Validation_Report','Independent verification of figure data','report')


def review_atlas(book_names=None):
    # Compose the already-exported figure PDFs without resampling their text.
    import pypdf
    books={'RSCHA_Figure_Atlas.pdf':SPECS,
           'Legendre_Complete.pdf':[s for s in SPECS if 'Legendre' in s['title']],
           'Mehler_Complete.pdf':[s for s in SPECS if 'Mehler' in s['title']],
           'Constant_Complete.pdf':[s for s in SPECS if 'Zero-eigenvalue' in s['title']],
           'Geometry_and_Indices.pdf':[s for s in SPECS if s['category']=='geometry'],
           'Angular_and_Radial_Curves.pdf':[s for s in SPECS if s['category']=='curves']}
    for name,specs in books.items():
        if book_names is not None and name not in book_names:
            continue
        writer=pypdf.PdfWriter()
        for spec in specs:writer.append(str(ROOT/spec['pdf']),outline_item=spec['title'])
        with (ROOT/name).open('wb') as f:writer.write(f)
    canonical=[s for s in SPECS if not s['file'].startswith('supplement') and s['category']!='report']
    overview=Image.new('RGB',(1800,((len(canonical)+3)//4)*440),'#E9EEF1')
    for n,spec in enumerate(canonical):
        col,row=n%4,n//4
        im=Image.open(ROOT/spec['file']).convert('RGB');im.thumbnail((420,390))
        x=col*450+15+(420-im.width)//2;y=row*440+32+(390-im.height)//2
        overview.paste(im,(x,y))
        ImageDraw.Draw(overview).text((col*450+20,row*440+10),Path(spec['file']).name,fill=INK)
    overview.save(ROOT/'overview.png')
    (ROOT/'data'/'figure_manifest.json').write_text(json.dumps(SPECS,indent=2),encoding='utf-8')


def write_hash_manifest():
    output=ROOT/'data'/'sha256_manifest.txt'
    lines=[]
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path==output or '_archive' in path.parts or '__pycache__' in path.parts:
            continue
        lines.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.relative_to(ROOT).as_posix())
    output.write_text('\n'.join(lines)+'\n',encoding='utf-8')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--only',choices=['all','curves','atlases','geometry'],default='all')
    args=parser.parse_args()
    if args.only in ('all','geometry'):
        geometry();root_figure();rotation()
    if args.only in ('all','curves'):
        function_curves('legendre','fig4');function_curves('mehler','fig6');constant_curves();radial_curves()
    if args.only in ('all','atlases'):
        for family,number in [('legendre',5),('mehler',7),('constant',9)]:
            for q,letter in enumerate('abc'):
                # Basis functions and both derivative orders share the 3D display.
                view='3d'
                atlas(family,q,f'fig{number}({letter})',view)
                atlas(family,q,f'supplement/fig{number}({letter})_2d', '2d')
    if args.only=='all':export_data();guides();review_atlas();write_hash_manifest()
    print('Complete.',flush=True)


if __name__=='__main__':main()
