"""Vector redraws following the approved cap diagram and original fig11.

The cap uses the projection, palette and sparse white grid established in
Geometry_Algorithm_Figure/draw_geometry_algorithm.py. The rotation drawing
restores the original four-stage layout while using the handbook's X_g,
X-prime and X_c notation and its passive rotation matrices.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, FancyArrowPatch

INK = '#263B4B'
MUTED = '#788A96'
TEAL = '#347F87'
BLUE = '#4C73A9'
GOLD = '#B88942'
RED = '#B94E4D'


def hull(points):
    points=sorted(set(map(tuple,points)))
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    low=[];high=[]
    for p in points:
        while len(low)>=2 and cross(low[-2],low[-1],p)<=0:low.pop()
        low.append(p)
    for p in reversed(points):
        while len(high)>=2 and cross(high[-2],high[-1],p)<=0:high.pop()
        high.append(p)
    return np.array(low[:-1]+high[:-1])


def project_line(ax,points,projection,**kw):
    xy=np.asarray(points)@projection
    return ax.plot(xy[:,0],xy[:,1],**kw)


def projected_label(ax,point,text,projection,offset=(0,0),**kw):
    x,y=np.asarray(point)@projection
    kw.setdefault('color',INK);kw.setdefault('zorder',20)
    ax.text(x+offset[0],y+offset[1],text,**kw)


def globe(ax,radius,projection,view):
    ax.add_patch(Circle((0,0),radius,fc='#F0F4F6',ec='#CFDAE1',lw=1,zorder=0))
    phi=np.linspace(0,2*np.pi,501)
    pts=radius*np.array([np.cos(phi),np.sin(phi),np.zeros_like(phi)]).T
    for front,ls,alpha in [(False,(0,(3,4)),.6),(True,'-',.85)]:
        xy=pts@projection
        xy=np.where(((pts@view>=0)==front)[:,None],xy,np.nan)
        ax.plot(xy[:,0],xy[:,1],color='#B5C5CE',lw=.85,ls=ls,alpha=alpha,zorder=1)
    for lon in [-55,45]:
        t=np.linspace(-np.pi/2,np.pi/2,201);p=np.deg2rad(lon)
        pts=radius*np.array([np.cos(t)*np.cos(p),np.cos(t)*np.sin(p),np.sin(t)]).T
        project_line(ax,pts,projection,color='#D7E0E5',lw=.6,zorder=1)


def draw_geometry():
    fig=plt.figure(figsize=(12.4,7.1))
    elev=np.deg2rad(19)
    ex=np.array([1.,0.,0.]);ey=np.array([0.,np.sin(elev),np.cos(elev)])
    projection=np.column_stack([ex,ey]);view=np.cross(ex,ey)
    tilt=np.deg2rad(34);az=np.deg2rad(-12)
    rz=np.array([[np.cos(az),-np.sin(az),0],[np.sin(az),np.cos(az),0],[0,0,1]])
    axis=rz@np.array([np.cos(tilt),0.,np.sin(tilt)])
    u=rz@np.array([-np.sin(tilt),0.,np.cos(tilt)])
    w=rz@np.array([0.,1.,0.])
    theta0=np.deg2rad(30)
    def direction(t,p):
        t,p=np.broadcast_arrays(t,p)
        return np.cos(t)[...,None]*axis+np.sin(t)[...,None]*(np.cos(p)[...,None]*u+np.sin(p)[...,None]*w)
    phi=np.linspace(0,2*np.pi,801)
    ts=np.linspace(0,theta0,61);ps=np.linspace(0,2*np.pi,241)
    T,P=np.meshgrid(ts,ps,indexing='ij')
    cap=direction(T,P).reshape(-1,3)
    for panel in range(2):
        ax=fig.add_axes([.022+.495*panel,.13,.472,.80])
        ax.set(xlim=(-1.10,1.50),ylim=(-1.05,1.34));ax.set_aspect('equal');ax.axis('off')
        if panel==0:
            globe(ax,.94,projection,view)
            ra,rb=1.,1.38
            ax.add_patch(Polygon(hull(rb*cap@projection),closed=True,fc='#CFDDED',ec='none',alpha=.68,zorder=3))
            fp=np.linspace(np.pi,2*np.pi,301)
            wall=np.vstack([rb*direction(theta0,fp)@projection,ra*direction(theta0,fp[::-1])@projection])
            ax.add_patch(Polygon(wall,closed=True,fc='#E8CF9E',ec='none',alpha=.45,zorder=3.1))
            ax.add_patch(Polygon(hull(ra*cap@projection),closed=True,fc='#AED0CD',ec='none',alpha=.60,zorder=3.2))
            surfaces=[(ra,TEAL),(rb,BLUE)]
            outer=rb
            for p in [0,np.pi]:
                project_line(ax,np.array([ra*direction(theta0,p),rb*direction(theta0,p)]),projection,color=GOLD,lw=1.6,zorder=6)
            projected_label(ax,ra*direction(np.deg2rad(23),np.deg2rad(150)),r'$\Gamma_{r_a}$',projection,(-.14,-.015),fontsize=17,color=TEAL)
            outer_rim=rb*direction(theta0,phi)@projection
            rim_target=outer_rim[np.argmax(outer_rim[:,0])]
            ax.annotate(r'$\Gamma_{r_b}$',xy=rim_target,xytext=(1.22,-.12),
                        color=BLUE,fontsize=17,zorder=20,
                        arrowprops=dict(arrowstyle='-',color=BLUE,lw=.75))
            projected_label(ax,1.18*direction(theta0,np.deg2rad(135)),r'$\Omega$',projection,(.02,-.01),fontsize=22,color=GOLD)
            project_line(ax,np.array([[0,0,0],rb*direction(theta0,0)]),projection,color=MUTED,lw=.95,ls=(0,(4,4)),zorder=7)
            project_line(ax,np.array([[0,0,0],ra*direction(theta0,np.pi)]),projection,color=MUTED,lw=.95,ls=(0,(4,4)),zorder=7)
            projected_label(ax,.63*rb*direction(theta0,0),r'$r_b$',projection,(-.105,.015),fontsize=18)
            projected_label(ax,.55*ra*direction(theta0,np.pi),r'$r_a$',projection,(0,-.12),fontsize=18)
            p_radius=1.19
        else:
            a=1.02
            globe(ax,a,projection,view)
            ax.add_patch(Polygon(hull(a*cap@projection),closed=True,fc='#BAD6D6',ec='none',alpha=.92,zorder=3.2))
            surfaces=[(a,TEAL)];outer=a;p_radius=a
            projected_label(ax,a*direction(np.deg2rad(19),np.deg2rad(155)),r'$\mathcal{C}_{\theta_0}(a)$',projection,(.06,.12),fontsize=17,color=TEAL)
            project_line(ax,np.array([[0,0,0],a*direction(theta0,0)]),projection,color=MUTED,lw=.95,ls=(0,(4,4)),zorder=7)
            projected_label(ax,.62*a*direction(theta0,0),r'$a$',projection,(-.11,.01),fontsize=18)
        # Same coarse, legible white dashed graticule as the approved design.
        def grid(points):
            points=np.asarray(points);xy=points@projection
            xy=np.where((points@view>=0)[:,None],xy,np.nan)
            ax.plot(xy[:,0],xy[:,1],color='white',alpha=.86,lw=1.35,ls=(0,(2.4,2.5)),zorder=4,dash_capstyle='round')
        for f in [.36,.72]:grid(outer*direction(theta0*f,phi))
        for p in [-135,-75,-15,45]:grid(outer*direction(np.linspace(0,theta0,401),np.deg2rad(p)))
        for r,color in surfaces:
            rim=r*direction(theta0,phi);xy=rim@projection
            for front,ls,alpha,lw in [(False,(0,(3,3)),.48,.95),(True,'-',.98,1.6)]:
                q=np.where(((rim@view>=0)==front)[:,None],xy,np.nan)
                ax.plot(q[:,0],q[:,1],color=color,ls=ls,alpha=alpha,lw=lw,zorder=5)
        project_line(ax,np.array([[0,0,-1.01],[0,0,1.18]]),projection,color='#A1B0BA',lw=.95,ls=(0,(5,4)),zorder=2)
        projected_label(ax,[0,0,1.18],r'$Z_g$',projection,(.025,.015),fontsize=17)
        end=1.62*axis@projection;start=-.09*axis@projection
        ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=12,color=INK,lw=1.1,ls=(0,(5,4)),zorder=6))
        ax.text(end[0]-.035,end[1]+.07,r'$Z_c$',color=INK,fontsize=17,ha='right',zorder=20)
        arc=np.linspace(0,theta0,101)
        project_line(ax,.45*direction(arc,0),projection,color=GOLD,lw=1.6,zorder=8)
        projected_label(ax,.50*direction(theta0*.53,0),r'$\theta_0$',projection,(.02,.02),fontsize=18,color=GOLD)
        ptheta,pphi=np.deg2rad(22),np.deg2rad(185)
        p=p_radius*direction(ptheta,pphi)
        project_line(ax,np.array([[0,0,0],p]),projection,color=INK,lw=.9,ls=(0,(2,3)),zorder=8)
        xy=p@projection;ax.scatter(*xy,s=22,color=INK,zorder=10)
        ax.annotate(r'$P(r,\theta,\lambda)$' if panel==0 else r'$P(a,\theta,\lambda)$',xy=xy,xytext=(.72,-.34),fontsize=15,color=INK,
                    arrowprops=dict(arrowstyle='-',color=MUTED,lw=.8),zorder=20)
        project_line(ax,.40*direction(np.linspace(0,ptheta,100),pphi),projection,color=INK,lw=1.15,zorder=9)
        ax.text(.205,.025,r'$\theta$',fontsize=17,color=INK,zorder=20)
        ax.scatter([0],[0],s=15,color=INK,zorder=12)
        ax.text(-.078,-.14,r'$O$',fontsize=17,color=INK,zorder=20)
    fig.text(.038,.963,'(a)  Closed spherical-cap shell',fontsize=19,weight='bold',color=INK)
    fig.text(.533,.963,'(b)  Spherical-cap surface',fontsize=19,weight='bold',color=INK)
    fig.text(.265,.075,r'$r_a\leq r\leq r_b,\quad 0\leq\theta\leq\theta_0,\quad0\leq\lambda<2\pi$',ha='center',fontsize=14,color=INK)
    fig.text(.76,.075,r'$r=a,\quad 0\leq\theta\leq\theta_0,\quad0\leq\lambda<2\pi$',ha='center',fontsize=14,color=INK)
    return fig


def draw_rotation():
    # This orthographic view restores the original figure's X down-left,
    # Y down-right, Z vertical arrangement. Axes are physical basis vectors;
    # the corresponding coordinate maps are the handbook's passive matrices.
    fig=plt.figure(figsize=(11.5,11.6))
    elev=np.deg2rad(18)
    ex=np.array([-.58,np.sqrt(1-.58**2),0.])
    ey=np.array([-ex[1]*np.sin(elev),ex[0]*np.sin(elev),np.cos(elev)])
    projection=np.column_stack([ex,ey]);view=np.cross(ex,ey)
    lam,theta=np.deg2rad(65),np.deg2rad(42)
    rz=np.array([[np.cos(lam),np.sin(lam),0],[-np.sin(lam),np.cos(lam),0],[0,0,1]])
    ry=np.array([[np.cos(theta),0,-np.sin(theta)],[0,1,0],[np.sin(theta),0,np.cos(theta)]])
    initial=np.eye(3);intermediate=rz.T;final=(ry@rz).T
    center=final[:,2]
    radius=.93
    def axis(ax,direction,color,label,length=1.62,offset=(0,0),muted_inside=False,alpha=1.):
        end=length*direction@projection
        if muted_inside:
            stop=min(1.,radius/np.linalg.norm(end))
            ax.plot([0,stop*end[0]],[0,stop*end[1]],color=color,lw=1.8,alpha=.35,zorder=4)
            start=stop*end
            if stop<1:
                ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=15,lw=1.9,color=color,zorder=8))
        else:
            ax.add_patch(FancyArrowPatch((0,0),end,arrowstyle='-|>',mutation_scale=15,lw=1.85,color=color,alpha=alpha,zorder=8))
        if label:
            xy=1.045*end
            ax.text(xy[0]+offset[0],xy[1]+offset[1],label,ha='center',va='center',fontsize=19,color=color,alpha=alpha,zorder=20)
    def frame(ax,mat,color,labels,muted=False,skip=(),alpha=1.):
        for n in range(3):
            if n not in skip:axis(ax,mat[:,n],color,labels[n],muted_inside=muted,alpha=alpha)
    def meridian(ax):
        t=np.linspace(0,2*np.pi,801)
        pts=radius*(np.sin(t)[:,None]*intermediate[:,0]+np.cos(t)[:,None]*initial[:,2])
        xy=pts@projection
        for near,alpha,lw in [(False,.26,.85),(True,.72,1.05)]:
            q=np.where(((pts@view>=0)==near)[:,None],xy,np.nan)
            ax.plot(q[:,0],q[:,1],color=MUTED,lw=lw,ls=(0,(4,4)),alpha=alpha,zorder=3)
    def angle_arrow(ax,points,color):
        xy=points@projection
        ax.plot(xy[:-5,0],xy[:-5,1],color=color,lw=1.45,zorder=12)
        ax.add_patch(FancyArrowPatch(xy[-8],xy[-1],arrowstyle='->',mutation_scale=13,lw=1.45,color=color,zorder=12))
    positions=[(.025,.535),(.52,.535),(.025,.065),(.52,.065)]
    names=['(a)  Global frame','(b)  Longitude rotation','(c)  Colatitude rotation','(d)  Cap-centred frame']
    for panel,(x,y) in enumerate(positions):
        ax=fig.add_axes([x,y,.455,.415]);ax.set_aspect('equal');ax.axis('off')
        ax.set(xlim=(-1.13,1.66),ylim=(-1.43,1.77))
        ax.add_patch(Circle((0,0),radius,fc='#EDF0F2',ec='#D2DCE1',lw=.9,zorder=0))
        # A single faint equatorial ellipse gives depth without a wire globe.
        t=np.linspace(0,2*np.pi,401)
        equator=radius*np.array([np.cos(t),np.sin(t),np.zeros_like(t)]).T
        xy=equator@projection
        for near,ls,alpha in [(False,(0,(3,4)),.28),(True,'-',.38)]:
            q=np.where(((equator@view>=0)==near)[:,None],xy,np.nan)
            ax.plot(q[:,0],q[:,1],color='#B9C7CF',lw=.6,ls=ls,alpha=alpha,zorder=1)
        if panel==0:
            frame(ax,initial,INK,[r'$X_g$',r'$Y_g$',r'$Z_g$'],muted=True)
        elif panel==1:
            frame(ax,initial,INK,[r'$X_g$',r'$Y_g$',''],muted=True,skip=(2,),alpha=.6)
            meridian(ax)
            frame(ax,intermediate,BLUE,[r"$X'$",r"$Y'$",r"$Z'=Z_g$"])
            t=np.linspace(0,lam,101)
            points=.64*np.array([np.cos(t),np.sin(t),np.zeros_like(t)]).T
            angle_arrow(ax,points,BLUE)
            ax.text(-.06,-.40,r'$\lambda_c$',color=BLUE,fontsize=17,zorder=20)
        elif panel==2:
            frame(ax,intermediate,BLUE,[r"$X'$",'',r"$Z'$"] ,skip=(1,),alpha=.72)
            meridian(ax)
            frame(ax,final,RED,[r'$X_c$','',r'$Z_c$'])
            ypos=.93*(1.62*final[:,1]@projection)
            ax.text(ypos[0],ypos[1]+.13,r"$Y_c=Y'$",ha='center',va='bottom',
                    fontsize=18,color=RED,zorder=20)
            t=np.linspace(0,theta,101)
            points=.78*(np.sin(t)[:,None]*intermediate[:,0]+np.cos(t)[:,None]*initial[:,2])
            angle_arrow(ax,points,RED)
            ax.text(.20,.79,r'$\theta_c$',color=RED,fontsize=17,zorder=20)
        else:
            frame(ax,final,RED,[r'$X_c$',r'$Y_c$',r'$Z_c$'],muted=True)
        c=radius*center@projection
        ax.scatter(*c,s=23,facecolor='white',edgecolor=GOLD,linewidth=1.2,zorder=16)
        ax.scatter(*c,s=3,color=GOLD,zorder=17)
        if panel in (0,3):ax.text(c[0]+.045,c[1]+.01,r'$C$',color=GOLD,fontsize=16,zorder=20)
        ax.scatter([0],[0],s=10,color=INK,zorder=15)
        fig.text(x+.018,y+.422,names[panel],fontsize=16,weight='bold',color=INK)
    fig.text(.29,.515,r"$\mathbf{x}'=R_z(\lambda_c)\,\mathbf{x}_g$",ha='center',fontsize=15,color=BLUE)
    fig.text(.765,.515,'Z axis unchanged',ha='center',fontsize=12,color=MUTED)
    fig.text(.29,.039,r"$\mathbf{x}_c=R_y(\theta_c)\,\mathbf{x}'$",ha='center',fontsize=15,color=RED)
    fig.text(.765,.039,r'$R_y(\theta_c)R_z(\lambda_c)\,\widehat{\mathbf{c}}_g=(0,0,1)^{\mathsf{T}}$',ha='center',fontsize=13,color=RED)
    fig.text(.5,.008,'Global axes: graphite     Intermediate axes: blue     Cap axes: red     C: fixed cap centre',ha='center',fontsize=11,color=MUTED)
    return fig
