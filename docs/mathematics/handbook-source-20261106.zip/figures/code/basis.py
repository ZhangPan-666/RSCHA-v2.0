"""Low-order reference basis for the complete R-SCHA illustration suite.

No residual atlas is approximated or copied here. Analytic regular solutions
are evaluated directly at the modest plotting orders, then checked against
independent high-precision formulas by validate.py. Numerical runtime details
are deliberately kept out of these pure-mathematics illustrations.
"""
from functools import lru_cache
import math
import numpy as np
from scipy.special import hyp2f1, gammaln, roots_legendre
from scipy.optimize import brentq

APERTURE_DEG = 30.0
T0 = np.deg2rad(APERTURE_DEG)
RA, RB = 1.0, 2.0
S = math.log(RB / RA)
MAX_INDEX = 4


def gauss(n=256):
    x, w = roots_legendre(n)
    return (x + 1.0) * T0 / 2.0, w * T0 / 2.0


def mehler_series(m, tau, z):
    """F, F_z, F_zz in the positive sin(theta)^m regular representation."""
    z = np.asarray(z, dtype=float)
    term, tz, tzz = np.ones_like(z), np.zeros_like(z), np.zeros_like(z)
    f, fz, fzz = term.copy(), tz.copy(), tzz.copy()
    lam = tau * tau + 0.25
    for k in range(1, 1025):
        factor = ((m + k) * (m + k - 1) + lam) / (k * (m + k))
        tzz, tz, term = ((tzz * z + 2 * tz) * factor,
                         (tz * z + term) * factor, term * factor * z)
        f += term
        fz += tz
        fzz += tzz
        if k > 15 and np.all(np.abs(term) < 2e-16 * np.abs(f)) and np.all(np.abs(tzz) < 2e-16 * (1 + np.abs(fzz))):
            return f, fz, fzz
    raise RuntimeError('Positive Mehler series did not converge')


def raw(family, i, m, theta):
    """Value and analytic theta derivatives, with exact regular polar limits."""
    theta = np.asarray(theta, dtype=float)
    t = np.maximum(theta, 1e-9)
    st, ct = np.sin(t), np.cos(t)
    z = np.sin(t / 2) ** 2
    if family == 'constant':
        y = np.tan(t / 2) ** m
        d = y * m / st
        dd = y * m * (m - ct) / st**2
        phase, a_axis, eig = 1, 0.5**m, 0.0
    else:
        if family == 'legendre':
            nu = degree(i, m)
            a, b, c = m - nu, m + nu + 1, m + 1
            f = hyp2f1(a, b, c, z)
            fz = a * b / c * hyp2f1(a + 1, b + 1, c + 1, z)
            fzz = a * (a + 1) * b * (b + 1) / (c * (c + 1)) * hyp2f1(a + 2, b + 2, c + 2, z)
            # The handbook defines Ferrers P with (-1)^m and its Schmidt
            # factor with a second (-1)^m. They cancel in the plotted
            # Schmidt function; its regular polar germ is positive.
            phase = 1
            eig = -nu * (nu + 1)
        elif family == 'mehler':
            tau = i * np.pi / S
            f, fz, fzz = mehler_series(m, tau, z)
            phase, eig = 1, tau*tau + 0.25
        else:
            raise ValueError(family)
        pre = phase * st**m
        y = pre * f
        d = pre * (m * ct / st * f + 0.5 * st * fz)
        dd = pre * ((m * (m - 1) * (ct/st)**2 - m) * f
                    + (m + 0.5) * ct * fz + 0.25 * st**2 * fzz)
        a_axis = phase
    at_axis = theta == 0
    if np.any(at_axis):
        y = np.where(at_axis, a_axis if m == 0 else 0.0, y)
        d = np.where(at_axis, a_axis if m == 1 else 0.0, d)
        dd = np.where(at_axis, eig / 2 if m == 0 else (2 * a_axis if m == 2 else 0.0), dd)
    return y, d, dd


def boundary_residual(nu, m):
    return np.sin(T0)**m * hyp2f1(m - nu, nu + m + 1, m + 1, np.sin(T0/2)**2)


@lru_cache(None)
def roots(m):
    found = []
    previous = m + 1e-7
    fp = boundary_residual(previous, m)
    for nu in np.arange(previous + 0.05, 160, 0.05):
        fn = boundary_residual(nu, m)
        if fp * fn < 0:
            found.append(brentq(lambda v: boundary_residual(v, m), previous, nu,
                                xtol=1e-13, rtol=2e-14))
            if len(found) == MAX_INDEX - m + 1:
                return tuple(found)
        previous, fp = nu, fn
    raise RuntimeError('Missing Legendre root')


def degree(k, m):
    return roots(m)[k - m]


@lru_cache(None)
def amplitude(family, i, m):
    if family == 'legendre':
        # Section 9: the Condon--Shortley phase of P is cancelled by the
        # phase in the geophysical Schmidt normalisation factor.
        nu = degree(i, m)
        return np.sqrt(2.0 if m else 1.0) * np.exp(0.5 * (gammaln(nu+m+1)-gammaln(nu-m+1))) / (2**m * math.factorial(m))
    t, w = gauss()
    y = raw(family, i, m, t)[0]
    return 1.0 / np.sqrt(np.sum(w * y*y * np.sin(t)))


def basis(family, i, m, theta):
    scale = amplitude(family, i, m)
    return tuple(scale * x for x in raw(family, i, m, theta))


def modes(family):
    if family == 'legendre':
        return [(k, m) for k in range(5) for m in range(k + 1)]
    if family == 'mehler':
        return [(p, m) for p in range(1, 5) for m in range(5)]
    return [(0, m) for m in range(5)]


def radial(p, r):
    r = np.asarray(r, dtype=float)
    if p == 0:
        return np.full_like(r, np.sqrt(RA/(RB-RA))), np.zeros_like(r), np.zeros_like(r)
    tau = p * np.pi / S
    t = np.log(r / RA)
    ap = np.sqrt(2 / (S * ((2*p*np.pi)**2 + S*S)))
    y = ap * np.sqrt(RA/r) * (2*p*np.pi*np.cos(tau*t) + S*np.sin(tau*t))
    d = -np.sqrt(RA*((2*p*np.pi)**2+S*S)/(2*S**3*r**3)) * np.sin(tau*t)
    dd = -2*d/r - (tau*tau+0.25)*y/r**2
    return y, d, dd
