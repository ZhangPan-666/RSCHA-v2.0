"""Independent high-precision checks for all 40 angular (index,m) pairs."""
from pathlib import Path
import csv
import json
import mpmath as mp
import numpy as np
from scipy.special import roots_legendre
from basis import basis, modes, degree, T0, RA, RB, S, gauss, radial

ROOT=Path(__file__).resolve().parents[1]
mp.mp.dps=60
MPT0=mp.mpf(30)*mp.pi/180
MPS=mp.log(2)


def reference(family,i,m):
    if family=='legendre':
        nu=mp.mpf(float(degree(i,m)))
        scale=mp.sqrt((2 if m else 1)*mp.gamma(nu+m+1)/mp.gamma(nu-m+1))/(2**m*mp.factorial(m))
        def f(t):
            return scale*mp.sin(t)**m*mp.hyp2f1(m-nu,nu+m+1,m+1,mp.sin(t/2)**2)
        return f
    if family=='mehler':
        tau=mp.mpf(i)*mp.pi/MPS
        def raw(t):
            return mp.re((2*mp.tan(t/2))**m*mp.hyp2f1(mp.mpf('.5')+1j*tau,mp.mpf('.5')-1j*tau,m+1,mp.sin(t/2)**2))
    else:
        def raw(t):return mp.tan(t/2)**m
    norm=mp.sqrt(mp.quad(lambda t:raw(t)**2*mp.sin(t),[0,MPT0/2,MPT0]))
    return lambda t:raw(t)/norm


def main():
    rows=[];norm_errors=[];ode_errors=[];legendre_gram=[]
    for family in ['legendre','mehler','constant']:
        for i,m in modes(family):
            ref=reference(family,i,m)
            for fraction in [.09,.37,.73,1.0]:
                t=MPT0*mp.mpf(str(fraction))
                actual=basis(family,i,m,np.array([float(t)]))
                for q in range(3):
                    expected=ref(t) if q==0 else mp.diff(ref,t,q)
                    error=abs(mp.mpf(float(actual[q][0]))-expected)/max(1,abs(expected))
                    rows.append({'family':family,'index':i,'m':m,'theta_fraction':fraction,'derivative_order':q,'scaled_error':float(error)})
            if family!='legendre':
                t,w=gauss(512);v=basis(family,i,m,t)[0]
                norm_errors.append(abs(float(np.sum(w*v*v*np.sin(t)))-1))
            t=np.array([.1,.4,.8])*T0
            y,d,dd=basis(family,i,m,t)
            lam=(-degree(i,m)*(degree(i,m)+1) if family=='legendre' else ((i*np.pi/S)**2+.25 if family=='mehler' else 0.0))
            lhs=dd+np.cos(t)/np.sin(t)*d-(lam+m*m/np.sin(t)**2)*y
            denom=np.maximum(1,np.abs(dd)+np.abs(np.cos(t)/np.sin(t)*d)+np.abs((lam+m*m/np.sin(t)**2)*y))
            ode_errors.extend(np.abs(lhs)/denom)
        print('checked',family,flush=True)
    t,w=gauss(512)
    for m in range(5):
        values=np.array([basis('legendre',k,m,t)[0] for k in range(m,5)])
        G=(values*(w*np.sin(t)))@values.T
        D=np.sqrt(np.diag(G));G/=D[:,None]*D[None,:]
        legendre_gram.append(float(np.max(np.abs(G-np.eye(len(G))))))
    gx,gw=roots_legendre(512);r=RA+(gx+1)*(RB-RA)/2;wr=gw*(RB-RA)/2
    values=np.array([radial(p,r)[0] for p in range(5)])
    rg=(values*wr)@values.T/RA
    bc=max(float(np.max(np.abs(radial(p,np.array([RA,RB]))[1]))) for p in range(5))
    root_res=[]
    for k,m in modes('legendre'):
        ref=reference('legendre',k,m)
        root_res.append(float(abs(ref(MPT0))))
    summary={'status':'PASS','precision_decimal_digits':60,'angular_reference_checks':len(rows),
        'max_scaled_value_or_derivative_error':max(r['scaled_error'] for r in rows),
        'max_cap_unit_norm_error_512_point_quadrature':max(norm_errors),
        'max_scaled_angular_ode_residual':float(max(ode_errors)),
        'max_normalized_legendre_gram_error':max(legendre_gram),
        'max_radial_gram_error':float(np.max(abs(rg-np.eye(5)))),
        'max_radial_neumann_boundary_derivative':bc,
        'max_schmidt_dirichlet_boundary_value':max(root_res),
        'legendre_real_modes':25,'mehler_real_modes':36,'constant_real_modes':9,
        'method':'Independent 60-digit hypergeometric values and symbolic differentiation by mpmath; cap normalisation checked with 512 rather than 256 Gauss points.',
        'scope':'Reference illustrations at order <=4, not a compiled C++ atlas benchmark.'}
    tests=[summary['max_scaled_value_or_derivative_error']<2e-10,
           summary['max_cap_unit_norm_error_512_point_quadrature']<2e-11,
           summary['max_scaled_angular_ode_residual']<2e-11,
           summary['max_normalized_legendre_gram_error']<2e-10,
           summary['max_radial_gram_error']<2e-11,bc<2e-11,max(root_res)<2e-10]
    if not all(tests):summary['status']='FAIL'
    out=ROOT/'data';out.mkdir(exist_ok=True)
    (out/'validation.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    with (out/'reference_errors.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps(summary,indent=2),flush=True)
    if summary['status']!='PASS':raise SystemExit(1)


if __name__=='__main__':main()
