﻿param([string]$LatexmkExe = "")
$ErrorActionPreference = "Stop"
if (-not $LatexmkExe) {
    $candidate = Get-Command latexmk -ErrorAction SilentlyContinue
    if ($candidate) { $LatexmkExe = $candidate.Source }
    elseif (Test-Path -LiteralPath 'D:\Latex\texlive\2026\bin\windows\latexmk.exe') {
        $LatexmkExe = 'D:\Latex\texlive\2026\bin\windows\latexmk.exe'
    } else { throw 'latexmk was not found. Install TeX Live or supply -LatexmkExe.' }
}
$handbookBuild = Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Path $handbookBuild -Force | Out-Null
# latexmk invokes BibTeX inside the output directory.
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'references.bib') -Destination $handbookBuild -Force
Push-Location $PSScriptRoot
try {
    & $LatexmkExe -pdf -g -interaction=nonstopmode -halt-on-error -file-line-error "-outdir=$($handbookBuild.Replace('\','/'))" main.tex
    if ($LASTEXITCODE -ne 0) { throw "LaTeX compilation failed: $LASTEXITCODE" }
    Copy-Item -LiteralPath (Join-Path $handbookBuild 'main.pdf') -Destination (Join-Path $PSScriptRoot 'main.pdf') -Force
    Copy-Item -LiteralPath (Join-Path $handbookBuild 'main.pdf') -Destination (Join-Path $PSScriptRoot 'Mathematical Foundations of Revised Spherical Cap Harmonic.pdf') -Force
    Copy-Item -LiteralPath (Join-Path $handbookBuild 'main.bbl') -Destination (Join-Path $PSScriptRoot 'main.bbl') -Force
} finally { Pop-Location }
