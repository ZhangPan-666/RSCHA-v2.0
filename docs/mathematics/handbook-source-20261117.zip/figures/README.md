# R-SCHA handbook figures through index four

The manuscript figures were regenerated for this edition. Earlier artwork and scripts are archived under `_archive/before_complete_refresh_20261024/`.

## Figure collections

- `overview.png` previews 16 manuscript figures.
- `RSCHA_Figure_Atlas.pdf` collects the manuscript and supplementary 2D and 3D figures, with notes and verification results.
- `Legendre_Complete.pdf`, `Mehler_Complete.pdf`, and `Constant_Complete.pdf` collect the three mode families and their curves.
- `Geometry_and_Indices.pdf` shows the geometry, roots, and coordinate rotation.
- `Angular_and_Radial_Curves.pdf` gives the four families of curves and their first and second derivatives.

## Mode coverage

| Family | Indices | Cosine modes | Sine modes | Real modes |
|---|---|---:|---:|---:|
| Legendre | `0 <= k <= 4`, `0 <= m <= k` | 15 | 10 | 25 |
| Mehler | `1 <= p <= 4` and `0 <= m <= 4`, independently | 20 | 16 | 36 |
| Constants (zero radial eigenvalue) | `0 <= m <= 4` | 5 | 4 | 9 |

Index four refers to the plotted coverage. The panels also show first and second derivatives. Mehler has independent radial and azimuthal ranges. The constant family represents the zero radial eigenvalue. The sine functions at `m = 0` vanish. The constant mode's derivative panels show zero explicitly.

The mode grids have nine columns, from `sin(4λ)`, `sin(3λ)`, `sin(2λ)`, `sin(λ)`, and `1` to `cos(λ)`, `cos(2λ)`, `cos(3λ)`, and `cos(4λ)`. The rows are `k = 0..4` for Legendre and `p = 1..4` for Mehler. Pale dashes identify indices outside the displayed Legendre triangle.

## Reference geometry and normalization

- The cap half-angle is `theta0 = 30 deg`.
- The illustrative shell uses `ra = 1`, `rb = 2`, `s = ln(2)`, and `tau_p = p*pi/ln(2)`. These parameters replace an earlier narrow-cap illustration and are intended for viewing the low-order modes.
- The Legendre functions use the geophysical Schmidt semi-normalization in Section 9. The Condon–Shortley factors of Ferrers and Schmidt cancel.
- Mehler and constant angular factors satisfy `integral A(theta)^2 sin(theta) dtheta = 1`.
- The radial functions satisfy `integral Rp(r)^2 dr = ra`.
- Angular derivatives are per radian. The abscissa may be labeled in degrees. Curves are grouped by `m` and use linear axes.

## 3D and 2D panels

Figures 5(a), 7(a), and 9(a) encode function values as radial relief. Blue, cream, and ochre red mark negative, zero, and positive values. The dashed circle gives the reference cap outline. Each panel is scaled by its own maximum absolute value. Function and derivative amplitudes are listed in `data/display_amplitudes.csv`.

Manuscript mode and derivative figures use 3D cap views. Corresponding 2D figures are in `supplement/`. Curve panels have boxed axes. Angular-derivative panels omit the coordinate pole, where coordinate derivatives can depend on the meridian.

## Figure files

| File | Contents |
|---|---|
| `fig1.png` | Tilted cap geometry with translucent boundaries and a dashed white grid. The closed shell is on the left and the cap surface on the right. |
| `fig2.png` | Legendre boundary curves versus continuous degree and the 15 noninteger roots. |
| `fig4.png` | Legendre functions and derivatives for all 15 `(k,m)` combinations. |
| `fig5(a–c).png` | 25 real Legendre modes and their first and second angular derivatives. |
| `fig6.png` | Mehler functions and derivatives for all 20 `(p,m)` combinations. |
| `fig7(a–c).png` | 36 real Mehler modes and their first and second angular derivatives. |
| `fig8.png` | Constant angular functions and derivatives, `m = 0..4`. |
| `fig9(a–c).png` | Nine real constant-family modes and their first and second angular derivatives. |
| `fig10.png` | Radial Neumann functions and derivatives, `p = 0..4`. |
| `fig11.png` | Global coordinates, longitude rotation, colatitude rotation, and final cap coordinates. The coordinate stages use black, blue, and red. |

Filenames match the LaTeX references. The backup captions are in `caption_sources/` in the figure archive. The revised handbook is compiled as `main.pdf` and as a PDF named for its title. The separate Mehler-index diagram was retired in this revision.

## Regenerate

- `code/basis.py` evaluates regular functions, normalization, noninteger roots, and analytical derivatives.
- `code/geometry_drawings.py` draws the cap geometry and four-stage coordinate rotation.
- `code/rebuild_all.py` rebuilds the figures, CSVs, and atlases.
- `code/validate.py` runs the independent 60-digit checks.
- `requirements.txt` lists the dependencies. `rebuild.ps1` accepts an optional `-PythonExe`.

From this directory:

```powershell
.\rebuild.ps1
```

Alternatively:

```bash
python -m pip install -r requirements.txt
python code/validate.py
python code/rebuild_all.py
```

To change the illustrative geometry, update `APERTURE_DEG`, `RA`, and `RB` in `code/basis.py`, the reference values in `code/validate.py`, and the corresponding descriptions in `code/rebuild_all.py`. The scripts target the displayed low-order range. High-order extensions require the project's stabilized evaluator and validation.

## Verification and artwork references

`data/validation.json` records 480 function and derivative checks. The 60-digit Mehler reference uses a separate hypergeometric representation, and angular norms were evaluated by independent 512-point Gauss quadrature. Other checks cover the angular ODE, Legendre orthogonality, radial orthogonality, and Neumann endpoint conditions. These results apply to the displayed figure data.

`vector/` contains individual PDFs and SVG line plots. `reports/` contains reading notes and check summaries. The six root-level atlases are assembled from the individual PDFs.

The approved `Geometry_Algorithm_Figure` artwork guided Figure 1's layout, transparency, and white grid. Figure dimensions are schematic. Numerical reference parameters are in `data/parameters.json`. Figure 11 uses orthographic projection to retain the spatial relationships of the axes. The cap center stays fixed across the four panels, and its direction is the rotated positive `Z_c` axis.
