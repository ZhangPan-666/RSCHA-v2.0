# R-SCHA 论文交付说明

更新时间：2026-10-24

## 当前交付版本

- 稿件修订标识：`manuscript-20261024`（软件版本仍为 v2.0.1）
- 论文：`Zhang et al., 2026, Manuscript_RSCHAFunctions`
- 当前 PDF：37 页，50 条参考文献
- 正文源文件：`Zhang et al., 2026, Manuscript_RSCHAFunctions.tex`
- 参考文献：`references.bib`
- 编译参考文献：同名 `.bbl`
- 正式 PDF：同名 `.pdf`
- 投稿亮点：`JCP_Highlights.txt`

## 目录内容

- `figures/`：正文图件和高清图件预览。
- `reproducibility/`：数值验证请求、参考生成脚本、谱线数据、反演参数和应用残差审计。
- `submission/`：JCP 投稿信草稿、声明文本和投稿准备说明。
- `Archive/`：正式修改前的备份。

## 2026-10-24 修订

- 论文题目保持 **Stable Computation of Revised Spherical Cap Harmonics**。
- 第 5 节及其参考误差评价小节的 “error measures” 改为 “error evaluation”。
- 基金资助更新为国家自然科学基金（42574077、42250103、42674085）及湖北省自然科学基金（2024AFE003）；尚未获批的实验室开放基金不列入。
- 第一作者 Pan Zhang 关联单位 1、2、3，保留现单位并补列地大学院及湖北省重点实验室。
- 投稿声明与说明同步更新；图件、数值源码和历史验收结果未改动。
- 已按 `pdflatex + bibtex + pdflatex + pdflatex` 重新编译，仍为 37 页、50 条参考文献；已检查首页、两处标题、基金及相邻页，最终编译日志无未定义引用或版面溢出警告。
- 当前稿件及可独立编译的源文件压缩包同步至 GitHub 的 `docs/manuscript/`，修订标识为 `manuscript-20261024`；数值软件 release 仍为 v2.0.1。

## 代码与下载

R-SCHA v2.0.1 的 OpenMP 和 MPI 源代码、查表文件、构建脚本、验证汇总和数学基础手册位于：

- GitHub 项目：https://github.com/ZhangPan-666/RSCHA-v2.0
- v2.0.1 发布版：https://github.com/ZhangPan-666/RSCHA-v2.0/releases/tag/v2.0.1

## 编译

在本目录依次运行：

```powershell
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
bibtex "Zhang et al., 2026, Manuscript_RSCHAFunctions"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
```

## 后续修改与 GitHub 同步要求

**后续任何修改都必须同步更新 GitHub。** 适用范围包括正文、参考文献、C++ 代码、OpenMP/MPI 版本、图件、复现脚本、验证数据、投稿附件和 README。

每次修改后按以下顺序执行：

1. 在本地完成修改并重新编译、检查 PDF 和必要的数值结果。
2. 更新版本号、变更说明和源文件压缩包。
3. 将对应文件提交并推送到 GitHub；代码或发布包有实质变化时创建新的 release/tag。
4. 同步修改论文中的 **Data and code availability**，使下载地址和版本号与 GitHub 当前内容一致。
5. 在本目录保留最终 PDF、TeX、BibTeX、图件和复现材料，并在 `Archive/` 保存替换前版本。

不能只更新本地文件而不更新 GitHub；也不能让论文写的版本号、下载地址和 GitHub 实际发布内容不一致。

## 投稿前人工核对

上传前请核对作者姓名、单位、邮箱、ORCID、通讯作者、作者贡献、经费声明、利益冲突声明、全体作者同意投稿以及期刊系统的文件类型要求。
