# R-SCHA manuscript delivery notes

This archive records the 2026-10-24 revision `manuscript-20261024` of **Stable Computation of Revised Spherical Cap Harmonics**. The compiled manuscript has 37 pages and 50 references. The corresponding TeX, PDF, BBL, and `references.bib` are in the source root. `figures/` contains the manuscript artwork, `reproducibility/` contains numerical inputs and audits, and `submission/` contains submission drafts and declarations. `JCP_Highlights.txt` contains the highlights. Pre-edit backups were kept in the working `Archive/` directory.

The revision changed the two error-evaluation headings in Section 5, updated national grants 42574077, 42250103, and 42674085 and Hubei grant 2024AFE003, and listed Pan Zhang's three affiliations. The laboratory open-fund award was pending. Declarations were updated with the manuscript. Figures, numerical sources, and historical results were carried forward.

The build used pdfLaTeX, BibTeX, and two more pdfLaTeX passes. The title, headings, and funding pages were reviewed, with all citations resolved and no overflow warnings. See the root README for build commands.

The manuscript and its standalone sources were published under `docs/manuscript/`. The delivery notes originally referenced software v2.0.1. Use the [repository](https://github.com/ZhangPan-666/RSCHA-v2.0) and its [release history](https://github.com/ZhangPan-666/RSCHA-v2.0/releases) to identify the desired code and lookup table.

For a subsequent revision, validate the manuscript locally, update the revision notes and source archive, commit the coordinated files, and keep the Data and code availability links accurate. Before submitting, verify names, affiliations, contact information and ORCIDs, contributions, funding, conflicts, all authors' approval, and the submission system's file requirements.
