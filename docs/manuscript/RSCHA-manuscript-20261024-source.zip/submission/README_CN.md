# JCP 投稿结构与附属文件

已在正文补齐 CRediT、Funding、Acknowledgements，并规范利益冲突声明。
Data and code availability 保持原 GitHub 版本链接与复现范围说明。
文末 AI 辅助声明按作者要求暂时移除，后续再补；脚本和绘图辅助记录保留在 reproducibility/ 文件夹中。

经费按作者于 2026-10-24 提供的信息更新：国家自然科学基金（42574077、42250103、42674085）及湖北省自然科学基金（2024AFE003）。实验室开放基金尚未获批，本版不列入。正文与 `Declarations_JCP.txt` 使用相同资助声明。

第一作者 Pan Zhang 保留现单位，并关联已列出的中国地质大学（武汉）地球物理与空间信息学院及地球内部多尺度成像湖北省重点实验室，正文上标为 1、2、3。

贡献按作者说明映射至 CRediT：Pan Zhang 负责
方法、主要分析与写作；Jinsong Du 负责总体规划、指导和项目管理；Jiaxuan Zhang
负责程序与计算实验。不添加 Funding acquisition、个人致谢或未确认的计算平台。

文件：

- `Cover_letter_JCP_draft.txt`：投稿信草稿，署名通讯作者，仅供核对和上传准备。
- `Declarations_JCP.txt`：便于填入投稿系统的声明文本。
- 上一级 `JCP_Highlights.txt`：5 条亮点，每条均少于85字符；单独上传，不放入正文。
- 主文件及 `figures/`、`references.bib`、`reproducibility/`：正文与源材料。

投稿系统还需人工填写或核对：三位作者的姓名、单位、邮箱与 ORCID（有则填），
通讯作者、作者贡献、利益冲突表单、全体作者对最终稿和投稿的同意、是否一稿多投、
数据使用条件，以及界面实际要求的文件格式。这里没有代作者作出尚未确认的共同
批准、签名或原创性声明，也没有向期刊发送或提交文件。

本研究不涉及人体或动物实验，不为此添加与论文无关的伦理或知情同意段落。
图形摘要未作为必交项目推定；如系统要求，可另行制作。
初投稿采用现有一致的作者-年份引用格式，未在本轮更换模板或重排正文内容。

政策核对（2026-10-18，以下均为官方来源）：

- JCP 作者指南：https://www.sciencedirect.com/journal/journal-of-computational-physics/publish/guide-for-authors
- Elsevier CRediT：https://www.elsevier.com/researcher/author/policies-and-guidelines/credit-author-statement
- 经费与利益冲突：https://www.elsevier.support/publishing/answer/what-are-conflict-of-interest-statements-funding-source-declarations-author-agreementsdeclarations-and-permission-notes
- AI政策（2026年6月更新）：https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals
- Highlights格式：https://www.elsevier.support/publishing/answer/how-do-i-include-highlights-with-my-manuscript

JCP 指南原页此次未成功加载，浏览器接口也被 Work 的 Local browser use 设置阻止。
已用可访问的 Elsevier 官方政策补齐声明和亮点格式；不将此标记为已经核验投稿
系统全部必填项目。上传时以 JCP 当前指南及 Editorial Manager 界面为准。
