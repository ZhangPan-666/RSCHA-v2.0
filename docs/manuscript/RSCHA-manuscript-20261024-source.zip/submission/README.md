# JCP submission materials

The manuscript includes CRediT, Funding, Acknowledgements, and a conflict-of-interest statement. Data and code availability identifies the repository versions and reproduction scope. The author deferred the AI-use declaration. The scripts and plotting records are in `reproducibility/`.

The 2026-10-24 funding statement lists the National Natural Science Foundation of China (42574077, 42250103, and 42674085) and the Natural Science Foundation of Hubei Province (2024AFE003). The pending laboratory open fund was excluded. `Declarations_JCP.txt` carries the same statement. Pan Zhang's three affiliations include his current institution, the School of Geophysics and Geomatics at China University of Geosciences (Wuhan), and the Hubei Subsurface Multi-scale Imaging Key Laboratory.

Author contributions follow the information supplied by the authors. Pan Zhang led methodology, analysis, and writing. Jinsong Du led overall planning, supervision, and project administration. Jiaxuan Zhang developed the software and performed computational experiments.

- `Cover_letter_JCP_draft.txt` is the corresponding author's draft.
- `Declarations_JCP.txt` supplies declaration text.
- `../JCP_Highlights.txt` contains five separate submission highlights of fewer than 85 characters each.
- The manuscript files, figures, bibliography, and reproduction materials are in the parent directory.

The submitting authors should verify names, affiliations, emails, ORCIDs, corresponding authorship, contributions, conflicts, consent, simultaneous submission status, data permissions, and the requested file formats. This record covers preparation. The study used no human or animal subjects. The current manuscript uses author–year citations. A graphical abstract can be prepared if requested by the journal.

The 2026-10-18 policy review used the available official Elsevier instructions. The current submission forms should be checked in Editorial Manager. [Author guide](https://www.sciencedirect.com/journal/journal-of-computational-physics/publish/guide-for-authors) · [Funding and declarations](https://www.elsevier.support/publishing/answer/what-are-conflict-of-interest-statements-funding-source-declarations-author-agreementsdeclarations-and-permission-notes) · [AI policy](https://www.elsevier.com/about/policies-and-standards/generative-ai-policies-for-journals) · [Highlights](https://www.elsevier.support/publishing/answer/how-do-i-include-highlights-with-my-manuscript)
