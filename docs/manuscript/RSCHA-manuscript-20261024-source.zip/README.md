# R-SCHA manuscript source

Revision `manuscript-20261024` contains 37 pages and 50 references. The TeX source is `Zhang et al., 2026, Manuscript_RSCHAFunctions.tex`. The matching PDF and BBL are the compiled manuscript and bibliography. The bibliography database is `references.bib`.

- `figures/` contains the artwork and high-resolution previews.
- `reproducibility/` contains numerical requests, reference scripts, spectra, and regional application audits.
- `JCP_Highlights.txt` contains five highlights, each under 85 characters.
- `submission/` contains the draft cover letter, declarations, and submission notes.
- `Archive/` was the working location for pre-edit backups.

Build from the extracted archive directory:

```powershell
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
bibtex "Zhang et al., 2026, Manuscript_RSCHAFunctions"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
```

The October 18 cleanup moved obsolete backups and revision logs out of the working folder. The October 24 revision retained the title, updated two error-evaluation headings, listed national and Hubei provincial funding, and gave the lead author affiliations 1, 2, and 3. The submission statements were synchronized with the manuscript. The laboratory open-fund application was pending. Data, figures, and code results refer to the saved versions.

Funding, CRediT, acknowledgments, and conflicts of interest are included. The AI-use statement was deferred at this revision. See `DELIVERY_README.md` and `submission/README.md`.
