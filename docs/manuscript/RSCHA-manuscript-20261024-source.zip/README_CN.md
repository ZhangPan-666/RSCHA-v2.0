# R-SCHA 论文工作目录

当前稿件：37 页，50 条参考文献。

- `Zhang et al., 2026, Manuscript_RSCHAFunctions.tex`：正文源文件。
- 同名 `.pdf`：当前编译稿；同名 `.bbl`：已生成的参考文献列表。
- `references.bib`：参考文献数据库。
- `figures/`：正文图件及高清 PNG 预览。
- `reproducibility/`：数值验证请求、参考脚本、谱线数据和应用统计审计；使用方法见其 README。
- `JCP_Highlights.txt`：5 条投稿亮点，每条少于85字符。
- `submission/`：JCP 投稿信草稿、独立声明文本和提交说明。
- `Archive/`：保留正式修改前的备份。

在本目录依次运行：

```powershell
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
bibtex "Zhang et al., 2026, Manuscript_RSCHAFunctions"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
```

2026-10-18 清理：过时备份和旧修订流水记录已移入回收站。正文、PDF、图件和复现材料未改动。

JCP 结构已补齐 Funding、CRediT、Acknowledgements 和利益冲突声明；文末 AI 声明暂缓。
经费与作者分工依据作者提供的信息填写，数据和代码声明保留。当前编译稿37页，
50条文献。详见 `submission/README_CN.md`。

详见 DELIVERY_README.md。

2026-10-24 修订（`manuscript-20261024`）：保持论文题目不变，将相关两处标题的 “error measures” 改为 “error evaluation”；补列国家自然科学基金和湖北省自然科学基金；第一作者关联单位 1、2、3。尚未获批的实验室开放基金不列入本版。投稿声明同步更新，数值结果和图件未作修改。
