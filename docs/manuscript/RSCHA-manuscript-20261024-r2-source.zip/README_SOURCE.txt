Current manuscript source, 25 October 2026.
Main file: Zhang et al., 2026, Manuscript_RSCHAFunctions.tex
Use pdflatex, bibtex8, pdflatex, pdflatex with references.bib present.
Keep build output outside the article working folder.
This revision changes only Figure 4 float placement to remove page 29 whitespace.
