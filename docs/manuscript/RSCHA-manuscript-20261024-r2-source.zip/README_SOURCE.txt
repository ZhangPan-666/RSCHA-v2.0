Current manuscript source, 25 October 2026.
Main file: Zhang et al., 2026, Manuscript_RSCHAFunctions.tex
Use pdflatex, bibtex8, pdflatex, pdflatex with references.bib present.
Keep build output outside the article working folder.
Current notation in Eq. (7): V_Leg^int and V_Leg^ext.
Figure 4 retains its corrected top-of-page placement on page 29.
