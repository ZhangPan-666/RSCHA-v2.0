"""Independent arbitrary precision references for the production basis functions."""
import struct
from functools import lru_cache
import mpmath as mp
import gmpy2

ALGORITHM_VERSION = "2"
PRECISIONS = (80, 120, 180)
REFERENCE_GOAL = "1e-25"


def binary64(bits):
    return mp.mpf(struct.unpack("<d", struct.pack("<Q", int(bits)))[0])

def hyper_ad2(m,nb,tb,digits):
 with mp.workdps(digits):
  n=mp.mpf(nb);t=mp.mpf(tb);s=mp.sin(t);c=mp.cos(t);z=mp.sin(t/2)**2;a=-n;b=n+1;cc=m+1
  pref=mp.exp((mp.log(1 if m==0 else 2)+mp.loggamma(n+m+1)-mp.loggamma(n-m+1))/2+m*mp.log(mp.tan(t/2))-mp.loggamma(m+1))
  h=mp.hyp2f1(a,b,cc,z,maxterms=1000000,maxprec=200000);h1=a*b/cc*mp.hyp2f1(a+1,b+1,cc+1,z,maxterms=1000000,maxprec=200000);h2=a*(a+1)*b*(b+1)/(cc*(cc+1))*mp.hyp2f1(a+2,b+2,cc+2,z,maxterms=1000000,maxprec=200000)
  return [pref*h,pref*(m*h/s+s*h1/2),pref*((m*(m-1)/(s*s)+m/(1+c))*h+(m+c/2)*h1+s*s*h2/4)]

def hyper_near_ad2(m,nb,tb,digits):
 with mp.workdps(digits):
  m=mp.mpf(m)
  n=mp.mpf(nb);t=mp.mpf(tb);s=mp.sin(t);c=mp.cos(t);g=n-m;z=mp.sin(t/2)**2;a=-g;b=2*m+g+1;cc=m+1
  pref=mp.exp((mp.log(1 if m==0 else 2)+mp.loggamma(n+m+1)-mp.loggamma(g+1))/2-m*mp.log(2)-mp.loggamma(m+1)+m*mp.log(s))
  h=mp.hyp2f1(a,b,cc,z,maxterms=1000000,maxprec=200000);h1=a*b/cc*mp.hyp2f1(a+1,b+1,cc+1,z,maxterms=1000000,maxprec=200000);h2=a*(a+1)*b*(b+1)/(cc*(cc+1))*mp.hyp2f1(a+2,b+2,cc+2,z,maxterms=1000000,maxprec=200000)
  cot=c/s
  return [pref*h,pref*(m*cot*h+s*h1/2),pref*((m*(m-1)*cot*cot-m)*h+(m+mp.mpf('.5'))*c*h1+s*s*h2/4)]

def hyper_center_ad2(m,nb,tb,digits):
 with mp.workdps(30):extra=int(mp.ceil(2*mp.mpf(m)*mp.cos(mp.mpf(tb))**2/mp.log(10)))+50
 with mp.workdps(digits+extra):
  m=mp.mpf(m);n=mp.mpf(nb);t=mp.mpf(tb);g=n-m;s=mp.sin(t);c=mp.cos(t);z=c*c
  h0=mp.sqrt(mp.pi)*mp.exp(mp.loggamma(m+1)-mp.loggamma(m+1+g/2))*mp.rgamma((1-g)/2)
  h1=-2*mp.sqrt(mp.pi)*mp.exp(mp.loggamma(m+1)-mp.loggamma(m+(g+1)/2))*mp.rgamma(-g/2)
  def triple(a,b,cc):
   return [mp.hyp2f1(a,b,cc,z,maxterms=1000000,maxprec=200000),a*b/cc*mp.hyp2f1(a+1,b+1,cc+1,z,maxterms=1000000,maxprec=200000),a*(a+1)*b*(b+1)/(cc*(cc+1))*mp.hyp2f1(a+2,b+2,cc+2,z,maxterms=1000000,maxprec=200000)]
  e=triple(-g/2,m+(g+1)/2,mp.mpf('.5'));o=triple((1-g)/2,m+(g+2)/2,mp.mpf('1.5'))
  h=h0*e[0]+h1*c*o[0]
  hc=h0*2*c*e[1]+h1*(o[0]+2*c*c*o[1])
  hcc=h0*(2*e[1]+4*c*c*e[2])+h1*(6*c*o[1]+4*c*c*c*o[2])
  pref=mp.exp((mp.log(1 if m==0 else 2)+mp.loggamma(n+m+1)-mp.loggamma(g+1))/2-m*mp.log(2)-mp.loggamma(m+1)+m*mp.log(s));cot=c/s
  return [pref*h,pref*(m*cot*h-s*hc),pref*((m*(m-1)*cot*cot-m)*h-(2*m+1)*c*hc+s*s*hcc)]


def legendre(m, n, theta, digits):
    if not theta:
        a = mp.exp((mp.log(1 if m == 0 else 2) + mp.loggamma(n+m+1)
                    - mp.loggamma(n-m+1))/2-m*mp.log(2)-mp.loggamma(m+1))
        return [mp.mpf(m == 0), a if m == 1 else mp.mpf(0),
                -n*(n+1)/2 if m == 0 else 2*a if m == 2 else mp.mpf(0)]
    if theta >= mp.mpf('1.48'):
        return hyper_center_ad2(m, n, theta, digits)
    return hyper_near_ad2(m, n, theta, digits)


def positive_hyper(m, tau, z, derivatives=False):
    lam = tau*tau + mp.mpf('.25')
    term = total = mp.mpf(1)
    s1 = s2 = mp.mpf(0)
    threshold = mp.eps/10000
    for k in range(1, 1000001):
        term *= ((k*(k-1)+lam)*z)/((m+k)*k)
        total += term
        if derivatives:
            s1 += k*term
            s2 += k*(k-1)*term
        bound = z*(1+lam/((k+1)*(k+1)))
        if bound < 1 and term*(k+1)**2/(1-bound)**3 < threshold*total:
            return (total, s1/z, s2/(z*z)) if derivatives else total
    raise ArithmeticError('positive hypergeometric series exhausted maxterms')


def mehler_raw(m, tau, theta, derivatives=False):
    if not theta:
        return ([mp.mpf(m == 0), mp.mpf(m == 1),
                 (tau*tau+mp.mpf('.25'))/2 if m == 0 else mp.mpf(2 if m == 2 else 0)]
                if derivatives else mp.mpf(m == 0))
    s, c = mp.sin(theta), mp.cos(theta)
    pref = (2*mp.tan(theta/2))**m
    z = mp.sin(theta/2)**2
    h = positive_hyper(m, tau, z, derivatives)
    if not derivatives:
        return pref*h
    h, h1, h2 = h
    return [pref*h, pref*(m*h/s+s*h1/2),
            pref*((m*(m-1)/(s*s)+m/(1+c))*h+(m+c/2)*h1+s*s*h2/4)]


@lru_cache(maxsize=12)
def gauss_nodes(count, digits):
    with mp.workdps(digits):
        nodes, weights = mp.gauss_quadrature(count, 'legendre')
        return tuple(zip(nodes, weights))


def bessel_ratio_bound(lower, upper):
    delta = upper-lower
    return mp.exp(-2*delta+4*mp.log1p(delta/(lower+2)))


def mehler_norm(m, tau, cap, digits):
    endpoint = mehler_raw(m, tau, cap)
    omega = mp.sqrt(m*m/mp.sin(cap)**2+tau*tau+mp.mpf('.25'))+1
    zcap = mp.sin(cap/2)**2
    precision = mp.mp.prec+32
    with gmpy2.context(precision=precision):
        z = gmpy2.mpfr(mp.nstr(zcap,mp.mp.dps+15))
        lam = gmpy2.mpfr(mp.nstr(tau*tau+mp.mpf('.25'),mp.mp.dps+15))
        term = total = gmpy2.mpfr(1)
        terms = [term]
        threshold = gmpy2.mpfr(2)**(-mp.mp.prec-12)
        for k in range(1,1000001):
            term *= ((k*(k-1)+lam)*z)/((m+k)*k)
            total += term
            terms.append(term)
            if k % 16 == 0:
                bound = z*(1+lam/((k+1)*(k+1)))
                if bound < 1 and term/(1-bound) < threshold*total:
                    break
        else:
            raise ArithmeticError('normalization series exhausted maxterms')
        coefficients = [term/total for term in terms]
    def profile(theta):
        with gmpy2.context(precision=precision):
            x = gmpy2.mpfr(mp.nstr(mp.sin(theta/2)**2/zcap,mp.mp.dps+15))
            value = gmpy2.mpfr(0)
            for coefficient in reversed(coefficients):
                value = gmpy2.fma(value,x,coefficient)
            return mp.mpf(str(value))*(mp.tan(theta/2)/mp.tan(cap/2))**m
    width = min(mp.mpf(60), omega*cap)
    target = mp.mpf(REFERENCE_GOAL)/100
    while True:
        if width >= omega*cap:
            tail = mp.mpf(0)
            break
        lower = cap-width/omega
        if lower <= 0:
            tail = mp.mpf(0)
        else:
            power_bound = (mp.tan(lower/2)/mp.tan(cap/2))**(2*m) if m else mp.mpf(1)
            k = mp.sqrt(tau*tau+mp.mpf('.25'))
            bessel_bound = bessel_ratio_bound(k*lower,k*cap)
            tail = cap*min(power_bound,bessel_bound)
        if tail < target/(100*omega):
            break
        width = min(width*mp.mpf('1.5'),omega*cap)
    knots = sorted(set([mp.mpf(0), width] + [mp.mpf(x) for x in (4,12,28) if x < width]))
    def integrate(count):
        total = mp.mpf(0)
        for left, right in zip(knots,knots[1:]):
            mid, half = (left+right)/2, (right-left)/2
            total += half*mp.fsum(weight*profile(cap-(mid+half*node)/omega)**2
                                  *mp.sin(cap-(mid+half*node)/omega)/omega
                                  for node,weight in gauss_nodes(count,digits))
        return total
    previous = integrate(24)
    for count in (48,96,192):
        value = integrate(count)
        if value > 0 and abs(value-previous)/value < target and tail/value < target:
            return endpoint*mp.sqrt(value), max(abs(value-previous)/value,tail/value)
        previous = value
    raise ArithmeticError('Mehler cap integral did not converge')


def constant(m, theta, cap):
    u = mp.tan(cap/2)
    norm = mp.sqrt(2*u*u/(m+1)*mp.hyp2f1(2,m+1,m+2,-u*u))
    if not theta:
        a = (1/(2*u))**m/norm
        return [1/norm if m == 0 else mp.mpf(0), a if m == 1 else mp.mpf(0),
                2*a if m == 2 else mp.mpf(0)]
    value = (mp.tan(theta/2)/u)**m/norm
    s, c = mp.sin(theta), mp.cos(theta)
    return [value, m*value/s, (m*(m-1)/(s*s)+m/(1+c))*value]


def sensitivity(m, n, theta, digits):
    h = mp.power(10,-digits//4)
    samples = [legendre(m,n+k*h,theta,digits+30) for k in (-2,-1,1,2)]
    return [(samples[0][j]-8*samples[1][j]+8*samples[2][j]-samples[3][j])/(12*h) for j in (0,1)]


def difference(first, second, omega, n, sensitivity_requested):
    amplitude = max(abs(second[0]),abs(second[1])/omega,abs(second[2])/omega**2)
    if not amplitude:
        return mp.mpf(0) if first == second else mp.inf
    errors = [abs(first[j]-second[j])/(amplitude*omega**j) for j in range(3)]
    if sensitivity_requested:
        scale = max(abs(second[3]),abs(second[4])/omega,amplitude/max(mp.mpf(1),n))
        errors += [abs(first[j]-second[j])/(scale*omega**(j-3)) for j in (3,4)]
    return max(errors)


def compute_mode(rows):
    family, m = rows[0]['family'], int(rows[0]['m'])
    requested = rows[0]['sensitivity_requested'] == '1'
    previous = None
    for attempt,digits in enumerate(PRECISIONS,1):
        with mp.workdps(digits+40):
            n,cap = binary64(rows[0]['parameter_bits']),binary64(rows[0]['theta0_bits'])
            norm, norm_error = mehler_norm(m,n,cap,digits+40) if family == 'Mehler' else (mp.mpf(1),mp.mpf(0))
            current = []
            for row in rows:
                theta = binary64(row['theta_bits'])
                if family == 'Legendre':
                    values = legendre(m,n,theta,digits+40)
                elif family == 'Mehler':
                    values = [x/norm for x in mehler_raw(m,n,theta,True)]
                elif family == 'Constant':
                    values = constant(m,theta,cap)
                else:
                    raise ValueError('unknown family '+family)
                values += sensitivity(m,n,binary64(row['theta_nu_bits']),digits+40) if requested else [mp.mpf(0),mp.mpf(0)]
                if any(not mp.isfinite(x) for x in values):
                    raise ArithmeticError('nonfinite reference')
                current.append(values)
            omega = n+1 if family == 'Legendre' else mp.hypot(n,m)+1 if family == 'Mehler' else m+1
            if previous is not None:
                errors = [difference(a,b,omega,n,requested) for a,b in zip(previous,current)]
                if max(errors) < mp.mpf(REFERENCE_GOAL) and norm_error < mp.mpf(REFERENCE_GOAL):
                    records = []
                    for row,values,error in zip(rows,current,errors):
                        record = dict(row,valid='1',backend='mpmath',algorithm_version=ALGORITHM_VERSION,
                                      digits=digits,convergence=mp.nstr(max(error,norm_error),18),
                                      status='converged',attempt_count=attempt,mpmath_version=mp.__version__)
                        for name,x in zip(('value','d1','d2','dnu','dtheta_dnu'),values):
                            record[name+'_sign'] = int(mp.sign(x))
                            record[name+'_log_abs'] = mp.nstr(mp.log(abs(x)),digits) if x else '0'
                        records.append(record)
                    return records
            previous = current
    raise ArithmeticError('reference precision refinement did not converge')

