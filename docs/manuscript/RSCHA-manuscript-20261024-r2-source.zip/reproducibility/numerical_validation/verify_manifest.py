"""Verify packaged snapshot hashes without third-party dependencies."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    manifest = json.loads((HERE / 'snapshot_manifest.json').read_text(encoding='utf-8'))
    failures = []
    for entry in manifest['files']:
        path = HERE / entry['path']
        if not path.is_file():
            failures.append(entry['path'] + ': missing')
            continue
        data = path.read_bytes()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            failures.append(entry['path'] + ': changed')
    print(json.dumps({'checked_files': len(manifest['files']), 'failures': failures}, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
