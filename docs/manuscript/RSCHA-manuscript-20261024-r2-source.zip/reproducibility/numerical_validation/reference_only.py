"""Regenerate arbitrary-precision references from archived exact requests only.

No C++ executable, compiler, production library, or original data path is used.
The unchanged run.generate API supplies isolated per-mode workers and deadlines.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[variable] = '1'

HERE = Path(__file__).resolve().parent
DATASETS = ('results', 'degree_sensitivity_results', 'edge_results', 'edge_degree_results')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def smoke_rows(rows, dataset):
    # Deterministic inexpensive cases; retain each row and its bit patterns intact.
    families = ('Legendre', 'Mehler', 'Constant') if dataset == 'results' else ('Legendre',)
    chosen = []
    for family in families:
        candidates = [row for row in rows if row['family'] == family]
        chosen.append(min(candidates, key=lambda r: (int(r['m']), abs(float(r['parameter'])),
                                                   abs(float(r['theta_degree']) - 1.0), int(r['id']))))
    return chosen


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', choices=('all',) + DATASETS, default='all')
    parser.add_argument('--smoke', action='store_true', help='Six inexpensive archived requests across four sets')
    parser.add_argument('--output', type=Path, default=HERE / 'regenerated')
    parser.add_argument('--workers', type=int, default=2)
    parser.add_argument('--mode-timeout', type=float, default=600)
    parser.add_argument('--worker-memory-mb', type=float, default=512)
    parser.add_argument('--self-check', action='store_true', help='Also execute all 24 original Python controls')
    args = parser.parse_args()
    if args.workers < 1 or args.mode_timeout <= 0 or args.worker_memory_mb <= 0:
        parser.error('workers, mode-timeout and worker-memory-mb must be positive')
    import mpmath
    import reference
    import run as original_runner
    from mpmath.libmp import BACKEND
    if mpmath.__version__ != '1.3.0' or reference.gmpy2.version() != '2.2.2':
        parser.error('Install requirements.txt: mpmath==1.3.0 and gmpy2==2.2.2')
    output = args.output.resolve()
    archive = (HERE / 'archive').resolve()
    if output == archive or archive in output.parents:
        parser.error('Output must be outside the immutable archive directory')
    output.mkdir(parents=True, exist_ok=True)
    report = {'scope': 'Python reference regeneration only; no C++ comparisons',
              'smoke': args.smoke, 'python': sys.version, 'platform': platform.platform(),
              'mpmath': mpmath.__version__, 'gmpy2': reference.gmpy2.version(),
              'arithmetic_backend': BACKEND, 'reference_sha256': sha256(HERE / 'reference.py'),
              'original_runner_sha256': sha256(HERE / 'run.py'), 'datasets': []}
    if args.self_check:
        checks = original_runner.self_check()
        original_runner.atomic_json(output / 'self_check.json', checks)
        report['new_self_check_count'] = len(checks)
    datasets = DATASETS if args.dataset == 'all' else (args.dataset,)
    passed = True
    for dataset in datasets:
        requests = archive / dataset / 'requests.csv'
        with requests.open(encoding='utf-8-sig', newline='') as stream:
            rows = list(csv.DictReader(stream))
        if not rows or len({r['id'] for r in rows}) != len(rows):
            raise ValueError('empty requests or duplicate ids in ' + dataset)
        if args.smoke:
            rows = smoke_rows(rows, dataset)
        target = output / dataset
        target.mkdir(parents=True, exist_ok=True)
        with (target / 'selected_requests.csv').open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        # Long manuscript staging paths can exceed Windows MAX_PATH when the
        # upstream API appends its 64-character cache key. Keep transient cache
        # files in a short system-temporary directory and retain final outputs.
        with tempfile.TemporaryDirectory(prefix='rscha-ref-') as temporary:
            temporary_output = Path(temporary)
            ok = original_runner.generate(rows, temporary_output, args.workers,
                                          args.mode_timeout, args.worker_memory_mb)
            for name in ('reference.csv', 'reference_report.json', 'progress.json'):
                if (temporary_output / name).exists():
                    shutil.copy2(temporary_output / name, target / name)
        report['datasets'].append({'dataset': dataset, 'selected_points': len(rows),
                                  'selected_ids': [r['id'] for r in rows],
                                  'archive_requests_sha256': sha256(requests), 'passed': ok})
        passed = passed and ok
    report['passed'] = passed
    original_runner.atomic_json(output / 'regeneration_summary.json', report)
    print(json.dumps(report, indent=2), flush=True)
    return 0 if passed else 3


if __name__ == '__main__':
    raise SystemExit(main())
