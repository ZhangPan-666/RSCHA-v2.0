# Compact numerical-validation reproducibility supplement

This supplement preserves the exact requested coordinates, Python reference
generator, and compact historical reports used for the manuscript's independent
point-reference comparisons. It also supplies a Python-only regeneration entry
point. It does not include production C++ sources, executables, the four complete
reference CSV files, or the large per-point C++ comparison tables.

## Archived inputs and historical results

The `archive/` directories are exact copies from
`Testv2.0/02_MpmathValidation` captured for this revision on 18 October 2026.

| Directory | Exact request rows | Historical reference rows |
|---|---:|---:|
| `results` | 39,950 | 39,950 |
| `degree_sensitivity_results` | 510 | 510 |
| `edge_results` | 439 | 439 |
| `edge_degree_results` | 96 | 96 |
| Total | 40,995 | 40,995 |

Each directory contains `requests.csv`, `reference_report.json`,
`self_check.json`, `mpmath_summary.csv`, `mpmath_failures.csv`, and
`progress.json`. The summaries describe historical C++ comparisons; they are
not results newly obtained while preparing this supplement. The report's
`reference_sha256` identifies the omitted full reference CSV. It is not a hash
of the request file or of this supplement's small smoke output.

Use the request bit-pattern columns, not reconstructed decimal degree values,
as the numerical inputs. `parameter_bits`, `theta_bits`, `theta0_bits`, and
`theta_nu_bits` preserve the actual binary64 inputs, including the separate angle
conversion used by the degree-sensitivity interface. IDs are unique only within
each dataset. The present edge archive has 439 requests; an older upstream README
count is not used here.

`reference.py` and `run.py` are unchanged copies of the original Python source.
The latter includes the original full validation entry point, which requires
omitted C++ files. **Use `reference_only.py`, not `python run.py`, for this
supplement.** The wrapper calls only its `self_check()` and `generate()` APIs;
it does not call `run.main()`, compile code, export new C++ requests, or compare
against C++ outputs. The original dependency list is retained as
`requirements_upstream.txt`; the reference-only dependency list needs two packages.

## Install and execute

Use Python 3.11 or later with a working gmpy2 wheel/build. From this directory:

```console
python -m venv .venv
```

Activate the environment (`.venv\Scripts\activate` on Windows or
`source .venv/bin/activate` on macOS/Linux), then run:

```console
python -m pip install -r requirements.txt
python verify_manifest.py
python reference_only.py --smoke --self-check --output regenerated_smoke
```

The smoke selection is deterministic: one inexpensive archived request from
each family in the main set, and one Legendre request from each other set
(six points total). It retains every field of each selected request unchanged.
The `--self-check` option additionally executes the original 24 Python controls.

To regenerate one entire archived set or all four:

```console
python reference_only.py --dataset edge_results --output regenerated_edges --self-check
python reference_only.py --dataset all --output regenerated_full --workers 2 --mode-timeout 600 --worker-memory-mb 512 --self-check
```

These full-regeneration commands are provided for reproducibility; they were
not executed while preparing this supplement. Outputs include newly generated
`reference.csv`, `reference_report.json`, `progress.json`, and the exact selected
requests under each dataset directory, plus a top-level regeneration summary.
Signs and logarithms preserve values outside the ordinary binary64 range.

Transient cache files use a short system temporary directory to avoid Windows
path-length limits. Set `TMP` and `TEMP` to a short writable directory before
running if the default temporary directory is restricted. The wrapper does not
retain cross-invocation caches. Per-mode deadlines and Windows worker memory
monitoring are inherited from the original runner; memory monitoring returns
zero on non-Windows systems and is not a portable memory cap.

## Executed smoke evidence and hashes

`smoke_verified/` contains the executed smoke outputs. The run completed with
exit code 0 using Python 3.12.14 (Windows AMD64), mpmath 1.3.0, gmpy2 2.2.2,
and mpmath's `gmpy` arithmetic backend. All six requests converged, all four
dataset reports have empty failure lists, and all 24 Python controls passed.
Request IDs are 32033/33512/26678 in the main set, 29874 in the degree set,
and 3 in each edge set; `selected_requests.csv` records their full coordinates.
The smoke run used a workspace-local dependency directory and a short writable
temporary directory; those environment-specific dependencies are not packaged.

The unchanged `reference.py` SHA-256 is
`d08a9aa80990a8490c5486007fa60708ed04cc6f0d42f344d97105eafdeced61`, matching
the source identity in all four archived reference reports. The unchanged
`run.py` SHA-256 is
`2e82b929d3155de3ad53d0e4cee9cd4fafb71faa39447f814e2a1ea74e3f1a78`.
`snapshot_manifest.json` records SHA-256 hashes and sizes for the packaged
sources, exact request archives, reports, and executed smoke outputs.
`python verify_manifest.py` checks those recorded files without numerical
dependencies. Extra locally regenerated outputs are ignored by the verifier.

## Scope of the evidence

Reference precision is refined through 80, 120, and, if needed, 180 decimal
digits with guard digits and a `1e-25` convergence target. Legendre references
use Gamma/hypergeometric formulas with analytic angular derivatives; degree
sensitivities use high-precision five-point differences. Mehler references use
a positive series and independent cap integration. Constant-family references
use the closed-form normalization implemented in the archived source. These
conventions are family-specific, not a common Schmidt normalization.

This smoke run verifies that the archived Python reference route operates on
a small subset with the pinned dependencies. It does not reproduce the full
40,995-point reference archive, recompute the historical C++ errors, validate
any present production source version, establish continuous-domain error bounds,
or reproduce root, norm-integration, identity, performance, or regional-model
experiments. In particular, the manuscript's degree-10^8 evidence consists of
identity checks outside this independent point-reference supplement. Regional
observational inputs and full inversion replication are outside this package.
