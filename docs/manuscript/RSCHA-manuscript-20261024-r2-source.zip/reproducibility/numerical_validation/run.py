"""Parallel, resumable mpmath validation with isolated per-mode deadlines."""
import argparse
import csv
import ctypes
import hashlib
import json
import multiprocessing
import os
import stat
import sys
from pathlib import Path
import subprocess
import tempfile
import time

sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

import mpmath
from mpmath.libmp import BACKEND
import reference

HERE = Path(__file__).resolve().parent
FIELDS = ['id','valid','value_sign','value_log_abs','d1_sign','d1_log_abs',
          'd2_sign','d2_log_abs','dnu_sign','dnu_log_abs','dtheta_dnu_sign',
          'dtheta_dnu_log_abs','convergence','digits','status','attempt_count',
          'elapsed_seconds','group_id','family','m','parameter','theta_degree','theta0_degree',
          'parameter_bits','theta_bits','theta0_bits','theta_nu_bits',
          'sensitivity_requested','backend','algorithm_version','mpmath_version']


def self_check():
    mp = mpmath
    errors = {}
    with mp.workdps(100):
        for m,n,t in [(0,'.375','.3'),(1,'1','.3'),(3,'73.375','.3'),
                       (512,'512.375','1.56'),(1000,'1200.375','.8')]:
            n,t = mp.mpf(n),mp.mpf(t)
            factor = mp.exp((mp.log(1 if m == 0 else 2)+mp.loggamma(n+m+1)-mp.loggamma(n-m+1))/2)
            def ferrers(theta):
                return factor*mp.legenp(n,-m,mp.cos(theta),type=2,maxterms=1000000,maxprec=200000)
            expected = [ferrers(t),mp.diff(ferrers,t),mp.diff(ferrers,t,2)]
            actual = reference.legendre(m,n,t,100)
            errors[f'Legendre_{m}_{n}'] = reference.difference(actual,expected,n+1,n,False)
            alternative = reference.hyper_ad2(m,n,t,100)
            errors[f'Legendre_hyper_{m}_{n}'] = reference.difference(actual,alternative,n+1,n,False)
        n,t,m = mp.mpf('73.375'),mp.mpf('.3'),3
        nu = reference.sensitivity(m,n,t,100)
        factor = lambda degree: mp.sqrt(2*mp.gamma(degree+m+1)/mp.gamma(degree-m+1))
        def f(degree,theta):
            return factor(degree)*mp.legenp(degree,-m,mp.cos(theta),type=2)
        expected = [mp.diff(lambda degree:f(degree,t),n),mp.diff(f,(n,t),(1,1))]
        errors['degree_derivatives'] = max(abs(a-b)/max(abs(b),mp.mpf(1)) for a,b in zip(nu,expected))
        for m,tau,t in [(0,'0','.3'),(3,'12.375','.8'),(1000,'1000.125','1.2')]:
            tau,t = mp.mpf(tau),mp.mpf(t)
            degree = mp.mpc('-.5',tau)
            def complex_raw(theta):
                value = mp.factorial(m)*2**m*mp.legenp(degree,-m,mp.cos(theta),type=2,maxterms=1000000,maxprec=200000)
                if abs(mp.im(value)) > mp.mpf('1e-70')*max(abs(value),mp.mpf(1)):
                    raise ArithmeticError('complex reference has a significant imaginary part')
                return mp.re(value)
            actual = reference.mehler_raw(m,tau,t,True)
            expected = [complex_raw(t),mp.diff(complex_raw,t),mp.diff(complex_raw,t,2)]
            errors[f'Mehler_{m}_{tau}'] = reference.difference(actual,expected,mp.hypot(m,tau)+1,tau,False)
        cap = mp.mpf(float(mp.pi/2))
        for m in (0,3,10000):
            def density(u):
                theta = cap-u/(m+1)
                return (mp.tan(theta/2)/mp.tan(cap/2))**(2*m)*mp.sin(theta)/(m+1)
            knots = sorted(set([mp.mpf(0),(m+1)*cap]+[mp.mpf(x) for x in (1,4,16,64) if x < (m+1)*cap]))
            integral = mp.quad(density,knots)
            endpoint = reference.constant(m,cap,cap)[0]
            errors[f'Constant_norm_{m}'] = abs(endpoint**2*integral-1)
        m,tau,cap = 3,mp.mpf('12.375'),mp.mpf('1.2')
        norm,mesh = reference.mehler_norm(m,tau,cap,100)
        lam = tau*tau+mp.mpf('.25')
        def boundary(parameter):
            return reference.mehler_raw(m,mp.sqrt(parameter-mp.mpf('.25')),cap,True)
        v = boundary(lam)
        dl = mp.diff(lambda parameter:boundary(parameter)[0],lam)
        dld = mp.diff(lambda parameter:boundary(parameter)[1],lam)
        identity = mp.sin(cap)*(v[0]*dld-v[1]*dl)
        if identity <= 0:
            raise ArithmeticError('nonpositive spectral norm identity')
        errors['Mehler_integral_vs_spectral_identity'] = abs(norm**2/identity-1)
        errors['Mehler_integral_mesh'] = mesh
        for lower,upper in [(0,1),('.1','2'),(1,10),(10,100),(100,1000)]:
            lower,upper = mp.mpf(lower),mp.mpf(upper)
            exact = (mp.besseli(0,lower)/mp.besseli(0,upper))**2
            if exact > reference.bessel_ratio_bound(lower,upper):
                raise ArithmeticError('Bessel ratio tail bound failed')
            errors[f'Bessel_tail_bound_{lower}_{upper}'] = max(mp.mpf(0),exact/reference.bessel_ratio_bound(lower,upper)-1)
    result = {k:mp.nstr(v,18) for k,v in errors.items()}
    if any(v > mp.mpf(reference.REFERENCE_GOAL) for v in errors.values()):
        raise ArithmeticError('independent reference checks failed: '+str(result))
    return result


def atomic_json(path, data):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,ensure_ascii=True),encoding='utf-8')
    temporary.replace(path)


def valid_cache(saved, key, rows, identity):
    if saved.get('key') != key or saved.get('status') != 'converged' or saved.get('requests') != rows or saved.get('identity') != identity:
        return False
    records = saved.get('records',[])
    if len(records) != len(rows):
        return False
    try:
        for row,record in zip(rows,records):
            if any(record.get(k) != value for k,value in row.items()):
                return False
            if record.get('backend') != 'mpmath' or record.get('mpmath_version') != mpmath.__version__ or record.get('algorithm_version') != reference.ALGORITHM_VERSION or record.get('status') != 'converged' or record.get('valid') != '1':
                return False
            if (int(record['digits']),int(record['attempt_count'])) not in ((120,2),(180,3)):
                return False
            error = mpmath.mpf(record['convergence'])
            if not mpmath.isfinite(error) or error < 0 or error > mpmath.mpf(reference.REFERENCE_GOAL):
                return False
            for name in ('value','d1','d2','dnu','dtheta_dnu'):
                if record[name+'_sign'] not in (-1,0,1) or not mpmath.isfinite(mpmath.mpf(record[name+'_log_abs'])):
                    return False
    except (KeyError,TypeError,ValueError):
        return False
    return True


def lower_priority():
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        kernel.SetPriorityClass.argtypes = (ctypes.c_void_p,ctypes.c_uint)
        kernel.SetPriorityClass(kernel.GetCurrentProcess(),0x4000)


def worker(pipe):
    lower_priority()
    while True:
        rows = pipe.recv()
        if rows is None:
            return
        start = time.perf_counter()
        try:
            records = reference.compute_mode(rows)
            state, message = 'converged', ''
        except Exception as error:
            state, message, records = 'reference_failed', str(error), []
        pipe.send(dict(status=state,message=message,records=records,
                       elapsed_seconds=time.perf_counter()-start))


def memory_mb(process):
    if os.name != 'nt':
        return 0
    class Counters(ctypes.Structure):
        _fields_ = [('cb',ctypes.c_uint32),('faults',ctypes.c_uint32)] + [(name,ctypes.c_size_t) for name in
                    ('peak','working','peak_paged','paged','peak_nonpaged','nonpaged','pagefile','peak_pagefile','private')]
    kernel = ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    query = ctypes.WinDLL('psapi').GetProcessMemoryInfo
    query.argtypes = (ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_uint32)
    handle = kernel.OpenProcess(0x410,False,process.pid)
    if not handle:
        return 0
    try:
        value = Counters()
        value.cb = ctypes.sizeof(value)
        return max(value.working,value.private)/1048576 if query(handle,ctypes.byref(value),value.cb) else 0
    finally:
        kernel.CloseHandle(handle)


def stop_worker(slot):
    process,pipe = slot['process'],slot['pipe']
    if process.is_alive():
        if slot['job'] is None and not pipe.closed:
            try:
                pipe.send(None)
            except (OSError,EOFError):
                process.terminate()
        else:
            process.terminate()
        process.join(timeout=2)
        if process.is_alive():
            process.kill()
            process.join(timeout=2)
    pipe.close()


def generate(rows, output, workers, timeout, memory_limit):
    started = time.perf_counter()
    identity = dict(algorithm_version=reference.ALGORITHM_VERSION,
                    source_sha256=hashlib.sha256((HERE/'reference.py').read_bytes()).hexdigest(),
                    mpmath_version=mpmath.__version__,gmpy2_version=reference.gmpy2.version(),arithmetic_backend=BACKEND,
                    precisions=list(reference.PRECISIONS),reference_goal=reference.REFERENCE_GOAL)
    grouped = {}
    for row in rows:
        mode = tuple(row[k] for k in ('family','m','parameter_bits','theta0_bits','sensitivity_requested'))
        grouped.setdefault(mode,[]).append(row)
    cache = output/'cache'
    cache.mkdir(parents=True,exist_ok=True)
    aggregate = {}
    reference_file, report_file = output/'reference.csv', output/'reference_report.json'
    if reference_file.exists() and report_file.exists():
        try:
            report = json.loads(report_file.read_text(encoding='utf-8'))
            digest = hashlib.sha256(reference_file.read_bytes()).hexdigest()
            if report.get('identity') == identity and report.get('reference_sha256') == digest and not report.get('failures'):
                with reference_file.open(encoding='utf-8',newline='') as stream:
                    for record in csv.DictReader(stream):
                        for name in ('value','d1','d2','dnu','dtheta_dnu'):
                            record[name+'_sign'] = int(record[name+'_sign'])
                        aggregate[record['id']] = record
        except (OSError,ValueError,KeyError):
            aggregate = {}
    jobs, results = [], []
    for mode_rows in grouped.values():
        key = hashlib.sha256(json.dumps([identity,mode_rows],sort_keys=True).encode()).hexdigest()
        file = cache/(key+'.json')
        consolidated = dict(key=key,status='converged',requests=mode_rows,identity=identity,
                            records=[aggregate.get(row['id'],{}) for row in mode_rows],message='')
        if valid_cache(consolidated,key,mode_rows,identity):
            consolidated['elapsed_seconds'] = float(consolidated['records'][0]['elapsed_seconds'])
            results.append(consolidated)
            continue
        if file.exists():
            try:
                saved = json.loads(file.read_text(encoding='utf-8'))
            except (ValueError,OSError):
                saved = {}
            if valid_cache(saved,key,mode_rows,identity):
                results.append(saved)
                continue
        jobs.append((key,file,mode_rows))
    total, resumed = len(grouped), len(results)
    print(f'{len(rows)} points / {total} modes; {workers} processes; {resumed} cached modes',flush=True)
    context = multiprocessing.get_context('spawn')
    pool = []
    def spawn():
        parent,child = context.Pipe()
        process = context.Process(target=worker,args=(child,))
        process.start()
        child.close()
        return dict(process=process,pipe=parent,job=None,start=0,completed=0,memory=0,checked=0)
    try:
        pool = [spawn() for _ in range(min(workers,len(jobs)))]
        last_report = 0
        while jobs or any(slot['job'] is not None for slot in pool):
            for index,slot in enumerate(pool):
                if slot['job'] is None and jobs:
                    slot['job'] = jobs.pop(0)
                    slot['pipe'].send(slot['job'][2])
                    slot['start'] = time.monotonic()
                if slot['job'] is None:
                    continue
                if time.monotonic()-slot['checked'] > 2:
                    slot['memory'] = memory_mb(slot['process'])
                    slot['checked'] = time.monotonic()
                failure = None
                if slot['memory'] > memory_limit:
                    failure = 'worker memory limit'
                elif slot['pipe'].poll():
                    try:
                        result = slot['pipe'].recv()
                    except (EOFError,OSError):
                        failure = 'worker exited without a result'
                elif not slot['process'].is_alive():
                    failure = 'worker exited without a result'
                elif time.monotonic()-slot['start'] > timeout:
                    failure = 'timeout'
                else:
                    continue
                if failure:
                    result = dict(status='timeout' if failure == 'timeout' else 'reference_failed',
                                  message=failure,records=[],elapsed_seconds=time.monotonic()-slot['start'])
                    stop_worker(slot)
                    pool[index] = spawn() if jobs else dict(slot,job=None)
                key,file,mode_rows = slot['job']
                result.update(key=key,identity=identity,requests=mode_rows)
                for record in result['records']:
                    record['elapsed_seconds'] = result['elapsed_seconds']
                atomic_json(file,result)
                results.append(result)
                slot['job'] = None
                slot['completed'] += 1
                if not failure and (slot['completed'] >= 20 or memory_mb(slot['process']) >= memory_limit/2):
                    stop_worker(slot)
                    pool[index] = spawn() if jobs else dict(slot,job=None)
            if time.monotonic()-last_report > 15:
                failures = sum(x['status'] != 'converged' for x in results)
                print(f'Completed {len(results)}/{total} modes; failed {failures}',flush=True)
                atomic_json(output/'progress.json',dict(completed_modes=len(results),total_modes=total,
                            failed_modes=failures,workers=workers,resumed_modes=resumed,
                            active_modes=[dict(family=slot['job'][2][0]['family'],m=slot['job'][2][0]['m'],
                            parameter=slot['job'][2][0]['parameter'],seconds=time.monotonic()-slot['start'],memory_mb=slot['memory'])
                            for slot in pool if slot['job'] is not None]))
                last_report = time.monotonic()
            time.sleep(.03)
    finally:
        for slot in pool:
            stop_worker(slot)
    records = sorted((row for result in results for row in result['records']),key=lambda r:int(r['id']))
    with (output/'reference.csv').open('w',newline='',encoding='utf-8') as stream:
        writer = csv.DictWriter(stream,FIELDS,extrasaction='ignore')
        writer.writeheader()
        writer.writerows(records)
    failures = [dict(status=x['status'],message=x['message'],requests=x['requests'])
                for x in results if x['status'] != 'converged']
    report = dict(identity=identity,requested_points=len(rows),reference_points=len(records),
                  total_modes=total,workers=workers,resumed_modes=resumed,failures=failures,
                  worker_memory_limit_mb=memory_limit,worker_recycle_modes=20,worker_recycle_memory_mb=memory_limit/2,
                  reference_seconds=time.perf_counter()-started,
                  reference_sha256=hashlib.sha256((output/'reference.csv').read_bytes()).hexdigest())
    atomic_json(output/'reference_report.json',report)
    atomic_json(output/'progress.json',dict(completed_modes=len(results),total_modes=total,
                failed_modes=len(failures),workers=workers,resumed_modes=resumed,active_modes=[]))
    if not failures and len(records) == len(rows):
        for result in results:
            file = cache/(result['key']+'.json')
            if file.exists():
                file.unlink()
        if not any(cache.iterdir()):
            if os.name == 'nt':
                cache.chmod(stat.S_IWRITE)
            cache.rmdir()
    return not failures and len(records) == len(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=HERE/'grid.csv')
    parser.add_argument('--output',type=Path,default=HERE/'results')
    parser.add_argument('--workers',type=int,default=min(2,max(1,(os.cpu_count() or 1)//4)))
    parser.add_argument('--mode-timeout',type=float,default=600)
    parser.add_argument('--worker-memory-mb',type=float,default=512)
    parser.add_argument('--degree-sensitivity',action='store_true')
    parser.add_argument('--reference-only',action='store_true')
    parser.add_argument('--skip-build',action='store_true')
    parser.add_argument('--self-check-only',action='store_true')
    args = parser.parse_args()
    lower_priority()
    for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        os.environ[variable] = '1'
    if args.workers < 1 or args.mode_timeout <= 0 or args.worker_memory_mb <= 0:
        parser.error('workers, mode-timeout and worker-memory-mb must be positive')
    if mpmath.__version__ != '1.3.0':
        parser.error('install the pinned requirements.txt before running')
    if reference.gmpy2.version() != '2.2.2':
        parser.error('install the pinned gmpy2==2.2.2 before running')
    args.output = args.output.resolve()
    args.output.mkdir(parents=True,exist_ok=True)
    checks = self_check()
    atomic_json(args.output/'self_check.json',checks)
    print(f'Independent reference controls: {len(checks)} passed',flush=True)
    if args.self_check_only:
        return 0
    if not args.skip_build:
        with tempfile.TemporaryDirectory(prefix='rscha02-build-') as directory:
            environment = dict(os.environ,RSCHA_02_OBJECT=str(Path(directory)/'validate_mpmath.obj'))
            subprocess.run(['cmd.exe','/c',str(HERE/'build.bat')],cwd=HERE,env=environment,check=True)
    executable = HERE/'validate_mpmath.exe'
    requests = args.output/'requests.csv'
    command = [str(executable),'--input',str(args.input.resolve())]
    if args.degree_sensitivity:
        command += ['--degree-sensitivity']
    subprocess.run(command+['--export-requests',str(requests)],cwd=HERE,check=True)
    with requests.open(encoding='utf-8',newline='') as stream:
        rows = list(csv.DictReader(stream))
    if not rows or len({r['id'] for r in rows}) != len(rows):
        raise ValueError('empty grid or duplicate point ids')
    start = time.perf_counter()
    if not generate(rows,args.output,args.workers,args.mode_timeout,args.worker_memory_mb):
        print('FAIL: unresolved references; see reference_report.json',flush=True)
        return 3
    print(f'References complete in {time.perf_counter()-start:.1f} seconds',flush=True)
    if not args.reference_only:
        return subprocess.run(command+['--reference-input',str(args.output/'reference.csv'),
                              '--output',str(args.output/'mpmath')],cwd=HERE).returncode
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
