"""Recheck Figure 3 spectra; fits are descriptive, not resolution estimates."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import numpy as np


def summarize(root, output, archived=False):
    output.mkdir(parents=True, exist_ok=True)
    all_results = {}
    for work in ('Work1', 'Work2'):
        spectra = {}
        provenance = {}
        for name in ('EMM2017', 'WDMAMv2', 'SH1050', 'OurRSCHA'):
            path = (root / work / (name + '.csv') if archived else
                    root / work / 'FastSHGrid' / 'LocalizedSpectra' / name / 'N16' / 'Spectrum_r6371200.csv')
            a = np.loadtxt(path, delimiter=',')
            if a.shape[1] != 2 or not np.all(np.isfinite(a)) or np.any(a[:, 1] <= 0):
                raise ValueError(f'Invalid spectrum: {path}')
            spectra[name] = a
            target = output / 'spectra' / work / (name + '.csv')
            target.parent.mkdir(parents=True, exist_ok=True)
            if path.resolve() != target.resolve():
                shutil.copy2(path, target)
            provenance[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        x = spectra['OurRSCHA'][:, 0]
        if not all(np.array_equal(x, a[:, 0]) for a in spectra.values()):
            raise ValueError('Spectral grids differ')
        fits = []
        for lo, hi in [(1800, 3900), (1800, 5100), (2100, 5100), (3300, 5700), (3900, 5700), (1800, 9084)]:
            mask = (x >= lo) & (x <= hi)
            xx, yy = x[mask], np.log(spectra['OurRSCHA'][mask, 1])
            slope, intercept = np.polyfit(xx, yy, 1)
            resid = yy - (intercept + slope * xx)
            r2 = 1 - np.dot(resid, resid) / np.sum((yy - np.mean(yy)) ** 2)
            fits.append({'requested_range': [lo, hi], 'actual_range': [float(xx[0]), float(xx[-1])],
                         'points': len(xx), 'slope_lnP_per_degree': float(slope),
                         'efolding_degree': float(-1 / slope), 'r_squared': float(r2),
                         'points_below_display_floor': int(np.sum(np.exp(yy) < 1e-4))})
        bins = []
        for lo, hi in [(108, 300), (300, 492), (492, 708), (708, 1050), (1050, 3000)]:
            m = (x >= lo) & (x <= hi)
            bins.append({'range': [lo, hi], 'regional_to_reference_power_ratios': {
                n: {'median': float(np.median(spectra['OurRSCHA'][m, 1] / spectra[n][m, 1])),
                    'minimum': float(np.min(spectra['OurRSCHA'][m, 1] / spectra[n][m, 1])),
                    'maximum': float(np.max(spectra['OurRSCHA'][m, 1] / spectra[n][m, 1]))}
                for n in ('EMM2017', 'WDMAMv2', 'SH1050')}})
        all_results[work] = {'provenance': provenance, 'semi_log_fits': fits, 'band_ratios': bins}
    (output / 'spectrum_reanalysis.json').write_text(json.dumps(all_results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({w: r['semi_log_fits'] for w, r in all_results.items()}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, help='Original Applications folder; omit to use archived spectra.')
    parser.add_argument('--output', type=Path, default=Path(__file__).parent / 'recomputed_spectra')
    args = parser.parse_args()
    summarize(args.root or Path(__file__).parent / 'spectra', args.output, archived=args.root is None)
