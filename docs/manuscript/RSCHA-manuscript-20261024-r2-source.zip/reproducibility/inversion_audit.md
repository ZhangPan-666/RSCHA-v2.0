# Inversion definition audit — 2026-10-18

Scope: read-only inspection of `E:\OneDrive\学习\R-SCHA Shell C++\v2.0mpi` and the existing `Testv2.0\Applications\Work1` / `Work2` inputs. No compilation, inversion, benchmark, or numerical rerun was performed. No project files on E: were modified.

## Objective and controls

For robust switch zero, the implemented objective is

\[
\Phi(m)=\|W_d(Am-d)\|_2^2+\lambda\|W_m(m-m_{\rm prior})\|_2^2,
\qquad (W_d)_{ii}=w_i/\sigma_i.
\]

The normal equations are

\[
Hm=b,\quad H=A^T W_d^2 A+\lambda W_m^2,\quad
b=A^T W_d^2 d+\lambda W_m^2m_{\rm prior}.
\]

`damping` is the direct multiplier lambda, not its square. `Inversion.h:99–102` sets the damping diagonal to `damping * Weight_Model[j]^2`; `138–147` sets the data row multiplier to `Weight_Data[i]/Sigma[i]` when robust switch is zero; `150–170` and `204–224` apply the normal operator and form its diagonal/RHS. There is no division of either objective term by the number of data or coefficients, and no matrix-norm or trace normalization of lambda. The MPI helper performs sums, not averages (`MPIParallel.h:106–119,122–159`).

Both `Applications/Work{1,2}/MPIInputs/Parameters_Inversion.dat` contain, in order, epsilon = 0.1, damping = 0.01, maximum iterations = 100, robust switch = 0, robust constant = 1.5. The reader maps these entries at `R_SCHA.h:781–785`. Both model-weight files contain 144,124 ones; both initial-model and prior-model files contain 144,124 zeros. All active data-weight files contain unity entries. Thus both application objectives reduce to

\[
\Phi(m)=\sum_i\left((Am-d)_i/\sigma_i\right)^2+0.01\sum_j m_j^2.
\]

This is uniform zeroth-order damping of the stored coefficients, not degree-dependent weighting or a physical spatial smoothness functional. The sigma values remain observation/component-specific input values. `Work1_RSCHAInversion.cpp:616–684` passes the assembled data, weights, and sigmas to the solver without additional scaling. Endpoint difference rows are endpoint 1 minus endpoint 2, without baseline-length division (`550–551,600–607,644–662`).

## Preconditioner and stopping

The solver applies symmetric diagonal preconditioning, with `F_jj = H_jj^(-1/2)`, preconditioned variable `z = F^(-1)m`, operator `H_tilde = F H F`, and RHS `b_tilde = F b`. A nonpositive diagonal receives `F_jj=0` instead; positive damping and unity model weights exclude that case here. The normal matrix is never explicitly formed (`Inversion.h:150–170,204–224,229–244`). Built-in basis scaling remains part of A; `R_SCHA.h:149,172–173,200–201` uses the minimum radius as reference and the legacy Schmidt convention. Algebraic preconditioning does not change the objective penalty.

Let `tau = 64 * numeric_limits<double>::epsilon()` = approximately 1.4210854715202004e-14 (`Inversion.h:81`). At a Krylov restart with `z0`, define

\[
c=\max\{\|\widetilde b\|_\infty,\|\widetilde H z_0\|_\infty\},\qquad
s=\|\widetilde b-\widetilde H z_0\|_\infty.
\]

The restart immediately converges if `s <= tau*c`. Otherwise the residual is divided by s internally and the recursive residual tolerance is `tau*c/s` (`229–244`). When that recursive residual is small, the solver recomputes the actual preconditioned normal-equation residual and accepts convergence only if

\[
\|\widetilde b-\widetilde H z\|_\infty
\leq\tau\max\{c,\|\widetilde H z\|_\infty\}.
\]

See `Inversion.h:295–304`. There is no model-change or relative-RMS convergence criterion. The printed RMS is unweighted, `sqrt(sum_i(d_i-(Am)_i)^2/N)` (`124–136`). The configured epsilon = 0.1 is checked only when damping equals zero (`186–189,285–288`), so this RMS stopping check is inactive for both application inputs with damping = 0.01. The loop is capped at 100 iterations (`195`).

No existing application execution logs or recorded termination/actual-iteration evidence were found. The cluster scripts would write `inversion.log` (`Work1/Cluster/run_inversion_forward.slurm:68` and the corresponding Work2 script), but those logs are absent locally. Therefore 100 is a configured maximum; actual convergence and actual iteration counts are unverified. Do not state that both application solutions converged or performed exactly 100 iterations on this evidence alone.

## Vector residual frame

The fitted vector components are local cap-north, cap-east, and radially downward. `CoordinateTransformation.h:70–73` converts transformed colatitude to cap latitude; `102–104`, `106–107`, and `109–111` project onto those three local directions. `Work1_RSCHAInversion.cpp:325–330` transforms each endpoint separately, then `650–662` subtracts their transformed components. Thus labels `Delta B_{x_c}`, `Delta B_{y_c}`, and `Delta B_z` are accurate if the caption states that horizontal components use the cap frame and z is positive down. These are local spherical-frame components, not fixed Cartesian axes.

## SHA-256 provenance

Paths below are relative to `E:\OneDrive\学习\R-SCHA Shell C++`. Hashes were calculated from the inspected files on 2026-10-18.

| Path | SHA-256 |
|---|---|
| `v2.0mpi/Inversion.h` | `ccedf0b4a0dcf45fdb1fcbad0dc8e0f049a3551080cc42b8cb8ca85c58610fc5` |
| `v2.0mpi/R_SCHA.h` | `e6141f1258077a1f6e85f39bfb3ada35185c42b6215cb12e04e55227725c8df8` |
| `v2.0mpi/Work1_RSCHAInversion.cpp` | `087bbfb31c258add46ca2c1b14fe5df23fa8597a1e2ccde584c961d7b389cd5c` |
| `v2.0mpi/MPIParallel.h` | `6d7f4a357f94a4ddd1a1e1dc42424223364d47ddef6528d5fa3494cf46bf9de4` |
| `v2.0mpi/CoordinateTransformation.h` | `c78b2cd7aff3aac029fdc17a205d327bc1ef143b3a1ab03e6485c051804ee30f` |
| `Testv2.0/Applications/Work1/MPIInputs/Parameters_Inversion.dat` | `38376e47934ac3524847cb43f418f67f3bcdc46ae2ec47918a2c41df5a993d94` |
| `Testv2.0/Applications/Work2/MPIInputs/Parameters_Inversion.dat` | `38376e47934ac3524847cb43f418f67f3bcdc46ae2ec47918a2c41df5a993d94` |
| `Testv2.0/Applications/Work1/MPIInputs/Parameters_ModelWeight.dat` | `912a367ba20767c13ecb4817f192ccc2a0370235b78e09e2a802552c414c73d6` |
| `Testv2.0/Applications/Work2/MPIInputs/Parameters_ModelWeight.dat` | `912a367ba20767c13ecb4817f192ccc2a0370235b78e09e2a802552c414c73d6` |
| `Testv2.0/Applications/Work1/MPIInputs/Parameters_InitialModel.dat` | `64a740efb6a641a85d5ad3b7b4dcaecf0528189e0b6d1a1b07ab4b3c9691c469` |
| `Testv2.0/Applications/Work2/MPIInputs/Parameters_InitialModel.dat` | `64a740efb6a641a85d5ad3b7b4dcaecf0528189e0b6d1a1b07ab4b3c9691c469` |
| `Testv2.0/Applications/Work1/MPIInputs/Parameters_PriorModel.dat` | `64a740efb6a641a85d5ad3b7b4dcaecf0528189e0b6d1a1b07ab4b3c9691c469` |
| `Testv2.0/Applications/Work2/MPIInputs/Parameters_PriorModel.dat` | `64a740efb6a641a85d5ad3b7b4dcaecf0528189e0b6d1a1b07ab4b3c9691c469` |
