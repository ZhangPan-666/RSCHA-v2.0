"""Audit existing application fits. Does not execute or modify any model/source input.

Run with Python + numpy + pandas:
  python audit_saved_residuals.py --root <Testv2.0> --output <this directory>
Large observation/reconstruction files are paired in 100,000-row chunks.
Only aggregate statistics, conventions, and file hashes are written.
Add --quantiles-only to recreate just near_surface_residual_quantiles.json.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import sys
from datetime import datetime, timezone

import numpy as np
import pandas as pd


class Stats:
    """Merge batch central moments; avoid subtracting large uncentred sums."""
    def __init__(self):
        self.n = 0
        self.mean = np.zeros(3)  # observed, predicted, residual
        self.m2 = np.zeros(3)
        self.cross = 0.0
        self.abs_residual_sum = 0.0
        self.min_residual = math.inf
        self.max_residual = -math.inf

    def add(self, observed, predicted):
        observed = np.asarray(observed, dtype=float).reshape(-1)
        predicted = np.asarray(predicted, dtype=float).reshape(-1)
        if not len(observed):
            return
        x = np.column_stack((observed, predicted, observed-predicted))
        assert np.isfinite(x).all()
        n = len(x)
        avg = x.mean(axis=0)
        centered = x-avg
        m2 = np.sum(centered*centered, axis=0)
        cross = float(centered[:, 0] @ centered[:, 1])
        if self.n:
            delta = avg-self.mean
            factor = self.n*n/(self.n+n)
            self.m2 += m2+delta*delta*factor
            self.cross += cross+delta[0]*delta[1]*factor
            self.mean += delta*n/(self.n+n)
        else:
            self.mean, self.m2, self.cross = avg, m2, cross
        self.n += n
        self.abs_residual_sum += float(np.abs(x[:, 2]).sum())
        self.min_residual = min(self.min_residual, float(x[:, 2].min()))
        self.max_residual = max(self.max_residual, float(x[:, 2].max()))

    def report(self, units="nT"):
        if not self.n:
            return {"count": 0}
        var = self.m2/self.n
        return {
            "count": self.n, "units": units,
            "residual_sign": "observed minus reconstructed",
            "observed_mean": float(self.mean[0]),
            "observed_std_population": float(np.sqrt(var[0])),
            "reconstructed_mean": float(self.mean[1]),
            "reconstructed_std_population": float(np.sqrt(var[1])),
            "residual_mean": float(self.mean[2]),
            "residual_std_population": float(np.sqrt(var[2])),
            "residual_rms": float(np.sqrt(var[2]+self.mean[2]**2)),
            "residual_mae": self.abs_residual_sum/self.n,
            "residual_min": self.min_residual,
            "residual_max": self.max_residual,
            "residual_max_abs": max(abs(self.min_residual), abs(self.max_residual)),
            "pearson_observed_reconstructed": float(self.cross/np.sqrt(self.m2[0]*self.m2[1]))
                if self.m2[0] and self.m2[1] else None,
        }


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4*1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def provenance(path):
    stat = path.stat()
    return {"path": str(path), "bytes": stat.st_size, "sha256": sha256(path)}


def audit_scalar_quantiles(p):
    """Exact empirical quantiles; retain only one absolute residual per row.

    Read source rows in chunks, verify the saved residual against observed minus
    reconstructed, and keep the absolute float64 residual vector in memory for
    exact quantiles. No histogram, sampling, or approximate quantile estimator.
    """
    source = p/"Recons_TMIData.dat"
    absolute_chunks = []
    maximum_identity_discrepancy = 0.0
    for chunk in pd.read_csv(source, sep=",", header=None, dtype=float,
                             usecols=[3, 4, 5], chunksize=100000):
        observed, reconstructed, residual = chunk.to_numpy().T
        assert np.isfinite(chunk.to_numpy()).all()
        maximum_identity_discrepancy = max(maximum_identity_discrepancy,
            float(np.max(np.abs(observed-reconstructed-residual))))
        absolute_chunks.append(np.abs(residual))
    assert maximum_identity_discrepancy < 1e-10
    absolute = np.concatenate(absolute_chunks)
    del absolute_chunks
    n = len(absolute)
    median, p95 = np.quantile(absolute, [0.5, 0.95], method="linear")
    total_squares = float(np.dot(absolute, absolute))
    # Exactly ceil(0.05*N) largest magnitudes: equal values at the boundary
    # contribute equally, so ties do not make this statistic ambiguous.
    tail_count = math.ceil(n*0.05)
    boundary = n-tail_count
    largest = np.partition(absolute, boundary)[boundary:]
    tail_squares = float(np.dot(largest, largest))
    return {
        "scope": "All fitted near-surface scalar-anomaly input nodes in the full 7.5-degree modeling cap, including LCS-1 gap values; not withheld validation",
        "source": provenance(source),
        "residual_source_column_1_based": 6,
        "residual_definition": "observed minus reconstructed; source columns 4 minus 5",
        "units": "nT",
        "count": n,
        "residual_identity_max_abs_discrepancy_nT": maximum_identity_discrepancy,
        "residual_rms_nT": math.sqrt(total_squares/n),
        "median_absolute_residual_nT": float(median),
        "p95_absolute_residual_nT": float(p95),
        "quantile_method": "numpy.quantile(abs(residual), [0.5,0.95], method='linear'); h=(N-1)*q, linear interpolation between floor(h) and ceil(h); exact empirical calculation from all float64 residuals",
        "tail_definition": "ceil(0.05*N) rows with largest absolute residual; ties at boundary have identical squared magnitude",
        "top_5_percent_count": tail_count,
        "top_5_percent_actual_fraction": tail_count/n,
        "top_5_percent_minimum_absolute_residual_nT": float(largest.min()),
        "top_5_percent_squared_residual_contribution_fraction": tail_squares/total_squares,
        "squared_residual_contribution_definition": "sum(residual_i^2 for the selected largest-magnitude rows)/sum(residual_i^2 for all rows); also their fractional contribution to mean squared residual",
        "sum_squared_residuals_nT2": total_squares,
        "top_5_percent_sum_squared_residuals_nT2": tail_squares,
    }


def write_scalar_quantile_supplement(root, output):
    report = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "audit_kind": "Exact near-surface residual quantiles and upper-tail squared contribution from existing saved reconstructions only",
        "software": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__},
        "audit_script": provenance(Path(__file__).resolve()),
        "memory_and_io_method": "Read 100,000 source rows per chunk; retain one float64 absolute residual per node for exact empirical quantiles; raw observations/residual vectors are not written",
        "works": {name: audit_scalar_quantiles(root/"Applications"/name/"MPIInputs")
                  for name in ["Work1", "Work2"]},
    }
    target = output/"near_surface_residual_quantiles.json"
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print("Saved "+str(target), flush=True)


def paired_chunks(observed_path, reconstruction_path, input_columns, output_columns):
    inp = pd.read_csv(observed_path, sep=r"\s+", header=None,
                      dtype=float, chunksize=100000)
    out = pd.read_csv(reconstruction_path, sep=",", header=None,
                      dtype=float, chunksize=100000)
    for a, b in itertools.zip_longest(inp, out):
        assert a is not None and b is not None, "Different row counts"
        a, b = a.to_numpy(), b.to_numpy()
        assert a.shape[0] == b.shape[0]
        assert a.shape[1] == input_columns and b.shape[1] == output_columns
        assert np.isfinite(a).all() and np.isfinite(b).all()
        yield a, b


def xyz(coords):
    lon, lat = np.deg2rad(coords[:, :2]).T
    r = coords[:, 2]
    return np.column_stack((r*np.cos(lat)*np.cos(lon), r*np.cos(lat)*np.sin(lon), r*np.sin(lat)))


def cap_angle(coords, center):
    lon, lat = np.deg2rad(coords[:, :2]).T
    lon0, lat0 = np.deg2rad(center)
    return np.rad2deg(np.arccos(np.clip(np.sin(lat)*np.sin(lat0)+np.cos(lat)*np.cos(lat0)*np.cos(lon-lon0), -1, 1)))


def to_cap(coords, values, center):
    """Equivalent to CoordinateTransformation.h SCHA_3CompsTrans(..., CTType=1).

    Both input/output are local north/east/down triples; output local horizontal
    axes refer to the cap pole. Rotating endpoints separately precedes subtraction.
    """
    lon, lat = np.deg2rad(coords[:, :2]).T
    lon0, colat0 = np.deg2rad([center[0], 90-center[1]])
    pos = xyz(np.column_stack((coords[:, :2], np.ones(len(coords)))))
    rotation = np.array([
        [np.cos(colat0)*np.cos(lon0), np.cos(colat0)*np.sin(lon0), -np.sin(colat0)],
        [-np.sin(lon0), np.cos(lon0), 0],
        [np.sin(colat0)*np.cos(lon0), np.sin(colat0)*np.sin(lon0), np.cos(colat0)]])
    rotated_pos = pos @ rotation.T
    cap_lon = np.arctan2(rotated_pos[:, 1], rotated_pos[:, 0])
    cap_lat = np.arctan2(rotated_pos[:, 2], np.hypot(rotated_pos[:, 0], rotated_pos[:, 1]))
    bx, by, bz = np.asarray(values).T
    ecef = np.column_stack((
        -np.sin(lat)*np.cos(lon)*bx-np.sin(lon)*by-np.cos(lat)*np.cos(lon)*bz,
        -np.sin(lat)*np.sin(lon)*bx+np.cos(lon)*by-np.cos(lat)*np.sin(lon)*bz,
        np.cos(lat)*bx-np.sin(lat)*bz))
    cx, cy, cz = (ecef @ rotation.T).T
    converted = np.column_stack((
        -np.sin(cap_lat)*np.cos(cap_lon)*cx-np.sin(cap_lat)*np.sin(cap_lon)*cy+np.cos(cap_lat)*cz,
        -np.sin(cap_lon)*cx+np.cos(cap_lon)*cy,
        -np.cos(cap_lat)*np.cos(cap_lon)*cx-np.cos(cap_lat)*np.sin(cap_lon)*cy-np.sin(cap_lat)*cz))
    assert np.max(np.abs(np.linalg.norm(converted, axis=1)-np.linalg.norm(values, axis=1))) < 1e-10
    return converted


def audit_scalar(p):
    fit = Stats()
    inside = Stats()
    maximum = dict(coordinates=0.0, observations=0.0, stored_residual_identity=0.0)
    center = np.loadtxt(p/"Parameters_Modelling.dat")[:2]
    for a, b in paired_chunks(p/"Data_TMI.dat", p/"Recons_TMIData.dat", 6, 6):
        maximum["coordinates"] = max(maximum["coordinates"], float(np.abs(a[:, :3]-b[:, :3]).max()))
        maximum["observations"] = max(maximum["observations"], float(np.abs(a[:, 3]-b[:, 3]).max()))
        maximum["stored_residual_identity"] = max(maximum["stored_residual_identity"], float(np.abs(b[:, 3]-b[:, 4]-b[:, 5]).max()))
        fit.add(a[:, 3], b[:, 4])
        mask = cap_angle(a[:, :3], center) <= 6.5+1e-9
        inside.add(a[mask, 3], b[mask, 4])
    assert maximum["coordinates"] < 1e-7 and maximum["observations"] < 1e-10
    assert maximum["stored_residual_identity"] < 1e-10
    return {"all_buffered_input_nodes": fit.report(), "interior_6p5_degree_nodes": inside.report(),
            "alignment_checks_max_abs": maximum,
            "scope": "Saved in-sample near-surface scalar-anomaly fit; includes NAMAG-CM nodes and LCS-1 filled nodes. Not withheld validation. TMI is linear projection on prescribed main-field direction, not full core-field intensity."}


def audit_pairs(p, vector):
    ncomp = 3 if vector else 1
    labels = ["Bx_north", "By_east", "Bz_down"] if vector else ["TMI"]
    endpoint1 = [Stats() for _ in labels]
    endpoint2 = [Stats() for _ in labels]
    pooled = [Stats() for _ in labels]
    difference = [Stats() for _ in labels]
    gradient = [Stats() for _ in labels]
    interior = [Stats() for _ in labels]
    cap_difference = [Stats() for _ in labels] if vector else None
    maximum = dict(coordinates=0.0, observations=0.0, stored_residual_identity=0.0)
    distance_range = [math.inf, -math.inf]
    center = np.loadtxt(p/"Parameters_Modelling.dat")[:2]
    inf = "Data_ALongTrackDiffVector.dat" if vector else "Data_ALongTrackDiffTMI.dat"
    outf = "Recons_ALongTrackDiffVectorData.dat" if vector else "Recons_ALongTrackDiffTMIData.dat"
    for a, b in paired_chunks(p/inf, p/outf, 12, 24 if vector else 12):
        c1, c2 = a[:, :3], a[:, 6:9]
        ob1, ob2 = a[:, 3:3+ncomp], a[:, 9:9+ncomp]
        if vector:
            bc1, bc2 = b[:, :3], b[:, 12:15]
            bo1, bo2 = b[:, 3:6], b[:, 15:18]
            pr1, pr2 = b[:, 6:9], b[:, 18:21]
            re1, re2 = b[:, 9:12], b[:, 21:24]
        else:
            bc1, bc2 = b[:, :3], b[:, 6:9]
            bo1, bo2 = b[:, 3:4], b[:, 9:10]
            pr1, pr2 = b[:, 4:5], b[:, 10:11]
            re1, re2 = b[:, 5:6], b[:, 11:12]
        maximum["coordinates"] = max(maximum["coordinates"], float(np.abs(c1-bc1).max()), float(np.abs(c2-bc2).max()))
        maximum["observations"] = max(maximum["observations"], float(np.abs(ob1-bo1).max()), float(np.abs(ob2-bo2).max()))
        maximum["stored_residual_identity"] = max(maximum["stored_residual_identity"], float(np.abs(bo1-pr1-re1).max()), float(np.abs(bo2-pr2-re2).max()))
        km = np.linalg.norm(xyz(c1)-xyz(c2), axis=1)/1000
        assert np.all(km > 0)
        distance_range = [min(distance_range[0], float(km.min())), max(distance_range[1], float(km.max()))]
        obdiff, prdiff = ob1-ob2, pr1-pr2
        mask = (cap_angle(c1, center) <= 6.5+1e-9) & (cap_angle(c2, center) <= 6.5+1e-9)
        if vector:
            ocap = to_cap(c1, ob1, center)-to_cap(c2, ob2, center)
            pcap = to_cap(c1, pr1, center)-to_cap(c2, pr2, center)
        for j in range(ncomp):
            endpoint1[j].add(ob1[:, j], pr1[:, j])
            endpoint2[j].add(ob2[:, j], pr2[:, j])
            pooled[j].add(np.concatenate((ob1[:, j], ob2[:, j])), np.concatenate((pr1[:, j], pr2[:, j])))
            difference[j].add(obdiff[:, j], prdiff[:, j])
            gradient[j].add(obdiff[:, j]/km, prdiff[:, j]/km)
            interior[j].add(obdiff[mask, j], prdiff[mask, j])
            if vector:
                cap_difference[j].add(ocap[:, j], pcap[:, j])
    assert maximum["coordinates"] < 1e-7 and maximum["observations"] < 1e-10
    assert maximum["stored_residual_identity"] < 1e-10
    result = {
        "pair_count": difference[0].n,
        "pair_definition": "(observed_endpoint1 - observed_endpoint2) - (reconstructed_endpoint1 - reconstructed_endpoint2)",
        "geographic_NED_pair_difference": {label: value.report() for label, value in zip(labels, difference)},
        "geographic_NED_pair_gradient": {label: value.report("nT/km = pT/m") for label, value in zip(labels, gradient)},
        "geographic_NED_pair_difference_interior_6p5_degree": {label: value.report() for label, value in zip(labels, interior)},
        "endpoint1_diagnostic": {label: value.report() for label, value in zip(labels, endpoint1)},
        "endpoint2_diagnostic": {label: value.report() for label, value in zip(labels, endpoint2)},
        "pooled_endpoint_occurrences_diagnostic": {label: value.report() for label, value in zip(labels, pooled)},
        "endpoint_note": "Endpoint occurrences can repeat across adjacent pairs; their residuals are diagnostics, not the differenced quantities fitted.",
        "chord_distance_km_min_max": distance_range,
        "alignment_checks_max_abs": maximum,
        "scope": "Saved in-sample satellite paired fit, full 7.5-degree buffer unless labelled interior; not withheld validation.",
    }
    if vector:
        result["solver_cap_frame_pair_difference"] = {
            label: value.report() for label, value in zip(["Bx_cap_north", "By_cap_east", "Bz_down"], cap_difference)}
        result["solver_frame_note"] = "Work1_RSCHAInversion.cpp transforms EACH NED endpoint using SCHA_3CompsTrans CTType=1 and then differences cap-frame components. The plotted geographic NED finite differences are not identical to this solver observable. Bz is radial/down and invariant under horizontal rotation."
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(r"E:\OneDrive\学习\R-SCHA Shell C++\Testv2.0"))
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--quantiles-only", action="store_true",
                        help="Recreate only the concise near-surface quantile/tail supplement")
    args = parser.parse_args()
    root = args.root.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    write_scalar_quantile_supplement(root, args.output)
    if args.quantiles_only:
        return
    previous_audit_path = root/"Applications"/"AdditionalFigures"/"application_input_audit.json"
    previous_audit = {x["work"]: x for x in json.loads(previous_audit_path.read_text(encoding="utf-8-sig"))}
    code_root = root.parent/"v2.0mpi"
    code_files = [code_root/name for name in ["R_SCHA.h", "Work1_RSCHAInversion.cpp", "CoordinateTransformation.h", "Inversion.h"]]
    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "audit_kind": "Statistics from already saved files only; no model rerun; source locations read-only",
        "software": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__},
        "definitions": {
            "rms": "sqrt(mean((observed - reconstructed)^2)); no demeaning; population denominator N",
            "correlation": "Pearson correlation of observed and reconstructed quantities",
            "coordinates": "geocentric longitude/latitude in degrees; geocentric radius in metres",
            "vector": "Bx=north, By=east, Bz=down in the local geographic geocentric frame in saved endpoint files",
            "difference": "Endpoint 1 minus endpoint 2; nT; no distance division",
            "gradient": "(endpoint1 - endpoint2)/3D ECEF chord length in km; nT/km, numerically pT/m; not a full gradient tensor",
            "recons_TMI_columns_1_based": ["longitude", "latitude", "radius", "observed TMI", "reconstructed TMI", "observed minus reconstructed"],
            "recons_DiffTMI_columns_1_based": ["lon1", "lat1", "r1", "observed1", "reconstructed1", "residual1", "lon2", "lat2", "r2", "observed2", "reconstructed2", "residual2"],
            "recons_DiffVector_columns_1_based": ["lon1", "lat1", "r1", "observed Bx1", "observed By1", "observed Bz1", "reconstructed Bx1", "reconstructed By1", "reconstructed Bz1", "residual Bx1", "residual By1", "residual Bz1", "lon2", "lat2", "r2", "observed Bx2", "observed By2", "observed Bz2", "reconstructed Bx2", "reconstructed By2", "reconstructed Bz2", "residual Bx2", "residual By2", "residual Bz2"],
            "code_evidence": ["v2.0mpi/R_SCHA.h lines 1940-2050: output columns", "v2.0mpi/Work1_RSCHAInversion.cpp lines 326-348, 569-667, 771-779: vector frame and paired data", "v2.0mpi/Inversion.h lines 124-136: logged misfit is unweighted aggregate RMS"],
            "model_provenance_limit": "Current source explains format and transformations, but no saved execution manifest links these exact source hashes to the application model run."
        },
        "source_files": [provenance(x) for x in code_files],
        "audit_script": provenance(Path(__file__).resolve()),
        "existing_figure_input_audit": provenance(previous_audit_path),
        "works": {},
    }
    for name in ["Work1", "Work2"]:
        print("Auditing "+name, flush=True)
        work = root/"Applications"/name
        p = work/"MPIInputs"
        scalar = audit_scalar(p)
        vector = audit_pairs(p, True)
        dtmi = audit_pairs(p, False)
        params = np.loadtxt(p/"Parameters_Inversion.dat")
        geom = np.loadtxt(p/"Parameters_Modelling.dat")
        metadata = json.loads((work/"Reports"/"mpi-inputs.json").read_text(encoding="utf-8-sig"))
        # Search only these application folders: regression-test logs elsewhere
        # belong to a different model and cannot establish application convergence.
        logs = [str(x) for x in work.rglob("*") if x.is_file() and x.suffix.lower() in {".log", ".out", ".err"}]
        files = [p/n for n in ["Data_TMI.dat", "Recons_TMIData.dat", "Data_ALongTrackDiffTMI.dat", "Recons_ALongTrackDiffTMIData.dat", "Data_ALongTrackDiffVector.dat", "Recons_ALongTrackDiffVectorData.dat", "Parameters_Inversion.dat", "Parameters_Modelling.dat", "Results_RSCHAModel.dat"]]
        files.extend([work/"Reports"/"mpi-inputs.json", work/"README.md"])
        file_provenance = [provenance(x) for x in files]
        current_model_hash = next(x["sha256"] for x in file_provenance if Path(x["path"]).name == "Results_RSCHAModel.dat")
        previous_model_hash = previous_audit[name]["input_sha256"][str(p/"Results_RSCHAModel.dat")]
        assert current_model_hash == previous_model_hash, "Model differs from existing figure audit"
        # Equivalent to source's unweighted mixed-observable data-misfit statistic,
        # reconstructed from outputs. It is not a convergence history or test error.
        entries = [scalar["all_buffered_input_nodes"], dtmi["geographic_NED_pair_difference"]["TMI"]]
        entries.extend(vector["solver_cap_frame_pair_difference"].values())
        total_n = sum(x["count"] for x in entries)
        total_rms = math.sqrt(sum(x["count"]*x["residual_rms"]**2 for x in entries)/total_n)
        item = {
            "region": "Cascadia" if name == "Work1" else "Midcontinent / Lake Superior",
            "geometry": {"cap_center_geocentric_lon_lat_degree": geom[:2].tolist(), "buffer_half_angle_degree": float(geom[2]), "interior_half_angle_degree": 6.5, "radius_min_max_m": [float(geom[8]), float(geom[7])]},
            "near_surface_scalar_fit": scalar,
            "satellite_vector_fit": vector,
            "satellite_TMI_fit": dtmi,
            "unweighted_aggregate_solver_observable_rms": {"count": total_n, "rms_nT": total_rms, "note": "Computed final saved-fit diagnostic, not logged convergence evidence; mixes scalar TMI and three cap-frame vector difference components, each in nT."},
            "near_surface_source_counts_from_preparation_report": {k: metadata.get(k) for k in ["observedTMINodes", "modelFilledTMINodes", "TMINodes"]},
            "near_surface_group_limit": "No source mask was loaded by this audit; reported scalar statistics combine original NAMAG-CM and LCS-1 gap-fill nodes. Counts are taken from existing preparation report, not a new per-source residual calculation.",
            "convergence_metadata": {
                "parameters": {"epsilon": float(params[0]), "damping": float(params[1]), "configured_maximum_iterations": int(params[2]), "robust_switch": int(params[3]), "robust_constant": float(params[4])},
                "application_runtime_log_candidates": logs,
                "actual_iterations": None,
                "termination_status": None,
                "misfit_history": None,
                "conclusion": "Application outputs exist, but no application runtime log/history was found. The maximum iteration setting is configuration only; neither actual iteration count nor convergence is established. README saying 20 iterations conflicts with current parameter value 100. Preparation report status data-prepared-not-inverted is stale relative to saved reconstruction outputs.",
            },
            "existing_figure_audit_model_hash_matches": True,
            "input_and_output_files": file_provenance,
        }
        result["works"][name] = item
        print(json.dumps({"work": name, "near_TMI_rms": scalar["all_buffered_input_nodes"]["residual_rms"], "near_TMI_correlation": scalar["all_buffered_input_nodes"]["pearson_observed_reconstructed"], "paired_TMI_rms": dtmi["geographic_NED_pair_difference"]["TMI"]["residual_rms"], "NED_vector_pair_rms": {k: v["residual_rms"] for k, v in vector["geographic_NED_pair_difference"].items()}, "cap_vector_pair_rms": {k: v["residual_rms"] for k, v in vector["solver_cap_frame_pair_difference"].items()}}), flush=True)
    target = args.output/"saved_application_residual_audit.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print("Saved "+str(target), flush=True)


if __name__ == "__main__":
    main()
