Saved application residual audit, 18 October 2026
================================================

This audit reads existing observation/reconstruction files under
`E:\OneDrive\学习\R-SCHA Shell C++\Testv2.0\Applications\Work1\MPIInputs`
and the corresponding `Work2\MPIInputs`. It does not rerun a model or change
anything under E:. Outputs here contain only scripts and aggregate statistics.

Geographic diagnostic and fitted cap-frame statistics
------------------------------------------------

All entries below are **paired in-sample residual RMS in nT**, over the full
7.5-degree buffered input cap, with no distance division and no demeaning.
The residual is `(observed1-observed2)-(reconstructed1-reconstructed2)`.
Bx/By/Bz refer to the saved geographic geocentric north/east/down components.
They therefore follow the coordinate convention of the existing satellite
gradient plots. These are fitted-data diagnostics, not withheld validation.

| Region | Vector pairs | TMI pairs | Bx RMS | By RMS | Bz RMS | TMI RMS |
|---|---:|---:|---:|---:|---:|---:|
| Cascadia / Work1 | 7,911 | 6,595 | 1.6091580847 | 0.7252435868 | 0.7036105265 | 0.7169211619 |
| Midcontinent / Lake Superior / Work2 | 7,802 | 6,556 | 2.2135328788 | 0.9274961609 | 1.1649742162 | 1.2831317421 |

At two decimals, vector values are `(1.61, 0.73, 0.70)` and
`(2.21, 0.93, 1.16)` nT. The existing TMI values **0.72 and 1.28 nT are
confirmed true paired residual RMS**, not endpoint statistics.

The revised manuscript table uses the fitted cap-frame components (rounded
to 1.47/1.74/0.70 and 2.23/1.63/1.16 nT), rather than the geographic diagnostic
values above. The solver rotates each vector endpoint separately into cap coordinates before
forming its difference. The horizontal component RMS of that actual solver
observable is different: Work1 `(1.4657750395, 1.7409691470, 0.7036105265)` nT;
Work2 `(2.2270547490, 1.6254149432, 1.1649742162)` nT. A manuscript using the
geographic values should label them explicitly as geographic north/east/down
pair differences rather than imply they are the cap-frame solver rows. The
vertical/radial component is unchanged by this horizontal-frame rotation.

Endpoint diagnostics (different quantities)
------------------------------------------

The `Recons_ALongTrackDiff*` files store **two endpoint reconstructions and two
endpoint residuals**, not an already differenced residual. Adjacent pairs can
share endpoints. Pooling both endpoint occurrences gives these diagnostic RMS:

| Region | Bx | By | Bz | TMI |
|---|---:|---:|---:|---:|
| Work1 | 5.9318293411 | 3.3445571623 | 2.5684341121 | 18.3489977077 |
| Work2 | 7.5062068200 | 3.9685089472 | 3.8781514116 | 12.5770528112 |

These endpoint values should not replace paired-difference fit statistics.

Near-surface percentiles and RMS contribution
--------------------------------------------

`near_surface_residual_quantiles.json` reproduces the median and P95 absolute
near-surface residuals reported in Table 10. It uses all fitted scalar rows in
the full modeling cap, including LCS-1 gap values. The source is column 6 of
`Recons_TMIData.dat`; every row is checked against columns 4 minus 5. Source
SHA-256 hashes and the generating script hash are recorded in the supplement.

| Region | Median absolute residual (nT) | P95 absolute residual (nT) | Squared-residual contribution from largest 5% |
|---|---:|---:|---:|
| Work1 | 10.1364367407 | 107.5668029483 | 80.0211% |
| Work2 | 15.3443081560 | 124.8975852700 | 87.7276% |

Quantiles use `numpy.quantile(..., method='linear')` on every absolute float64
residual, with index `(N-1)*q` and interpolation between its neighboring order
statistics. The source file is read in 100,000-row chunks; one float64 absolute
residual per node is retained in memory for the exact empirical calculation.
No sampling, histogram, or approximate quantile estimator is used.

The tail contains exactly `ceil(0.05*N)` largest absolute residuals. Its reported
contribution is their sum of squared residuals divided by the sum over all
nodes. The slight excess over 5% is caused only by rounding the node count up
to an integer. Boundary ties have identical squared magnitudes. These results
support the statement that a relatively small fraction of large residuals
contributes strongly to RMS. They do not establish independent predictive
accuracy.

Units, provenance, and limits
----------------------------

Coordinates are geocentric longitude/latitude in degrees and geocentric radius
in metres. Magnetic quantities are nT. Additional gradient residuals in the JSON
use the 3D ECEF endpoint chord in km, so their units are nT/km = pT/m. Geographic
component finite differences are not a full gradient tensor.

Near-surface scalar fit statistics were audited internally against their own
saved input rows. They include original NAMAG-CM nodes and LCS-1 gap-filled
nodes; no source mask was loaded here. They do not compare the regional model
with global reference models. There are no plots or new original-grid model
comparisons in this audit.

Current `Parameters_Inversion.dat` gives epsilon=0.1, damping=0.01,
maximum_iterations=100, robust_switch=0, robust_constant=1.5 for both regions.
No `.log`, `.out`, or `.err` application runtime file exists within either work
folder. Actual iteration count, termination status, and convergence history
cannot be recovered. Existing README text saying 20 iterations and preparation
reports saying not inverted are stale relative to the current parameter files
and reconstruction outputs. A configured maximum is not an actual iteration
count or evidence of convergence. Logs of separate regression tests cannot
establish convergence for these application runs.

Column and coordinate conventions were read from the current
`v2.0mpi/R_SCHA.h`, `Work1_RSCHAInversion.cpp`,
`CoordinateTransformation.h`, and `Inversion.h`. Their exact SHA-256 values and
all input/output SHA-256 values are recorded in the JSON. There is no saved run
manifest linking these exact source versions to the application execution, so
current source is evidence for file format/conventions, not a complete run
provenance chain. Both current `Results_RSCHAModel.dat` SHA-256 values match the
existing `AdditionalFigures/application_input_audit.json` model hashes.

Every reconstruction row was checked against the current corresponding input
row. Across both works, maximum coordinate discrepancy was 9.32e-10 m (radius);
maximum observation discrepancy was 9.10e-13 nT; maximum discrepancy in stored
`observed-reconstructed` residual identity was 1.82e-12 nT. All values were finite
and row counts matched. Large scalar files were read in 100,000-row chunks.

Reproduce
---------

Dependencies: Python, numpy, pandas. In PowerShell:

```powershell
python .\audit_saved_residuals.py --root 'E:\OneDrive\学习\R-SCHA Shell C++\Testv2.0'
```

The script's `--root` and `--output` arguments can override the input root and
summary destination. The default full audit recreates both the aggregate JSON
and the exact near-surface quantile supplement. To recreate only the supplement:

```powershell
python .\audit_saved_residuals.py --root 'E:\OneDrive\学习\R-SCHA Shell C++\Testv2.0' --quantiles-only
```

The packaged `saved_application_residual_audit.json` retains the earlier full
audit and its generating-script hash; the quantile supplement records the
extended script version used for the new percentile calculation. Their source
reconstruction hashes agree. The aggregate JSON additionally records residual means, population
standard deviations, MAE, extrema, internal observed/reconstructed correlations,
and the interior 6.5-degree subset. No raw observation rows are written.
