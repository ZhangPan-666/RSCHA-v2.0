# R-SCHA 论文工作目录

当前稿件：38 页，5 张图，50 条参考文献；修订标识 `manuscript-20261024-r2`。

- `Zhang et al., 2026, Manuscript_RSCHAFunctions.tex`：正文源文件。
- 同名 `.pdf`：当前编译稿；同名 `.bbl`：已生成的参考文献列表。
- `Zhang et al., 2026, Manuscript_RSCHAFunctions - manuscript-20261024-r2.pdf`：本次全文核查后的 38 页定稿 PDF；若同名旧 PDF 正被桌面预览锁定，优先使用该修订文件。
- `references.bib`：参考文献数据库。
- `figures/`：正文图件及高清 PNG 预览。
- `reproducibility/`：数值验证请求、参考脚本、谱线数据和应用统计审计；使用方法见其 README。
- `JCP_Highlights.txt`：5 条投稿亮点，每条少于85字符。
- `submission/`：JCP 投稿信草稿、独立声明文本和提交说明。
- `Archive/`：保留正式修改前的备份。

在本目录依次运行：

```powershell
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
bibtex "Zhang et al., 2026, Manuscript_RSCHAFunctions"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
pdflatex "Zhang et al., 2026, Manuscript_RSCHAFunctions.tex"
```

2026-10-18 清理：过时备份和旧修订流水记录已移入回收站。正文、PDF、图件和复现材料未改动。

JCP 结构已补齐 Funding、CRediT、Acknowledgements 和利益冲突声明；文末 AI 声明暂缓。
经费与作者分工依据作者提供的信息填写，数据和代码声明同步维护。当前编译稿 38 页、5 张图、50 条文献。详见 `submission/README_CN.md`。

详见 DELIVERY_README.md。

2026-10-24 修订（`manuscript-20261024`）：保持论文题目不变，将相关两处标题的 “error measures” 改为 “error evaluation”；补列国家自然科学基金和湖北省自然科学基金；第一作者关联单位 1、2、3。尚未获批的实验室开放基金不列入本版。投稿声明同步更新，数值结果和图件未作修改。

2026-10-24 第二次修订（`manuscript-20261024-r2`）：第 2 节插入几何与算法定稿图，并补写几何定义和算法章节衔接。图 1 代码与图件保存于工程根目录 `Geometry_Algorithm_Figure/`，正文引用 `figures/Fig1_Geometry_Algorithm.pdf`。原四张图自动顺延为图 2–5，文件名保持不变。核查报告和机器检查记录见 `reproducibility/editorial_audit_20261024/`。AI 使用声明按作者本次确认继续暂缓，草稿仅供后续审核。
